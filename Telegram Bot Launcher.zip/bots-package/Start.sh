#!/bin/bash
cd "$(dirname "$0")/telegram-clip-bot"
python3 launcher.py
