"""
thumbnail_maker.py
-------------------
Builds a split-layout vertical thumbnail (title banner / top photo / "WITH"
divider / bottom photo / "part N" badge) similar in structure to a viral
Shorts-style thumbnail, but with different display fonts.

Usage:
    python thumbnail_maker.py \
        --top-image me.jpg \
        --bottom-image guest.jpg \
        --title "Putting a 10ft Alligator in My Pool & Hiring a Pool Guy!" \
        --with-text "WITH" \
        --part-label "PART 2" \
        --out thumbnail.png

Fonts used (both bundled in assets/fonts/, SIL Open Font License):
  - Title text:        Poppins Bold Italic  (bold, matches the "Ranking funny
                        kids moments of 2024"-style reference — same font is
                        also used for the burned-in titles on generated clips)
  - WITH / part badge: Boldonse Regular     (chunky display)
Swap the FONT_TITLE / FONT_BADGE paths below (or pass your own reference
image) if you want to match a different font.
"""

import argparse
import os
import textwrap

from PIL import Image, ImageDraw, ImageFilter, ImageFont

CANVAS_W, CANVAS_H = 1080, 1920

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "assets", "fonts")
FONT_TITLE = os.path.join(ASSETS_DIR, "PoppinsBoldItalic.ttf")
FONT_BADGE = os.path.join(ASSETS_DIR, "Boldonse-Regular.ttf")


def _fit_image(path: str, target_w: int, target_h: int) -> Image.Image:
    """Center-crop an image to exactly fill target_w x target_h."""
    img = Image.open(path).convert("RGB")
    src_ratio = img.width / img.height
    dst_ratio = target_w / target_h

    if src_ratio > dst_ratio:
        new_height = target_h
        new_width = int(new_height * src_ratio)
    else:
        new_width = target_w
        new_height = int(new_width / src_ratio)

    img = img.resize((new_width, new_height), Image.LANCZOS)
    left = (new_width - target_w) // 2
    top = (new_height - target_h) // 2
    return img.crop((left, top, left + target_w, top + target_h))


def _draw_outlined_text(draw, xy, text, font, fill, outline, outline_width, anchor="mm"):
    x, y = xy
    for dx in range(-outline_width, outline_width + 1):
        for dy in range(-outline_width, outline_width + 1):
            if dx == 0 and dy == 0:
                continue
            draw.text((x + dx, y + dy), text, font=font, fill=outline, anchor=anchor)
    draw.text((x, y), text, font=font, fill=fill, anchor=anchor)


def _wrap_to_width(draw, text, font, max_width, max_lines=3):
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = f"{current} {word}".strip()
        if draw.textlength(trial, font=font) <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)

    if len(lines) > max_lines:
        lines = lines[:max_lines]
        while draw.textlength(lines[-1] + "…", font=font) > max_width and len(lines[-1]) > 1:
            lines[-1] = lines[-1][:-1]
        lines[-1] += "…"
    return lines


def _auto_font_size(draw, text, font_path, max_width, max_height, start_size=90, min_size=40):
    size = start_size
    while size > min_size:
        font = ImageFont.truetype(font_path, size)
        lines = _wrap_to_width(draw, text, font, max_width)
        line_height = size * 1.15
        total_height = line_height * len(lines)
        if total_height <= max_height:
            return font, lines
        size -= 4
    font = ImageFont.truetype(font_path, min_size)
    return font, _wrap_to_width(draw, text, font, max_width)


def build_thumbnail(
    top_image: str,
    bottom_image: str,
    title: str,
    with_text: str = "WITH",
    part_label: str = "PART 2",
    out_path: str = "thumbnail.png",
):
    canvas = Image.new("RGB", (CANVAS_W, CANVAS_H), "black")

    title_band_h = 320
    divider_h = 90
    photo_h = (CANVAS_H - title_band_h - divider_h) // 2

    top_photo = _fit_image(top_image, CANVAS_W, photo_h)
    bottom_photo = _fit_image(bottom_image, CANVAS_W, photo_h)

    canvas.paste(top_photo, (0, title_band_h))
    canvas.paste(bottom_photo, (0, title_band_h + photo_h + divider_h))

    draw = ImageDraw.Draw(canvas)

    # --- Title banner ---
    pad_x = 60
    title_font, title_lines = _auto_font_size(
        draw, title.upper(), FONT_TITLE,
        max_width=CANVAS_W - pad_x * 2, max_height=title_band_h - 60,
        start_size=110, min_size=44,
    )
    line_height = title_font.size * 1.15
    total_h = line_height * len(title_lines)
    y = (title_band_h - total_h) / 2 + line_height / 2
    for line in title_lines:
        _draw_outlined_text(
            draw, (CANVAS_W / 2, y), line, title_font,
            fill=(255, 255, 255), outline=(0, 0, 0), outline_width=6,
        )
        y += line_height

    # --- "WITH" divider between the two photos ---
    divider_y = title_band_h + photo_h + divider_h / 2
    badge_font = ImageFont.truetype(FONT_BADGE, 46)
    bbox = draw.textbbox((0, 0), with_text.upper(), font=badge_font)
    text_w = bbox[2] - bbox[0]
    strip_pad = 40
    draw.rectangle(
        [
            (CANVAS_W / 2 - text_w / 2 - strip_pad, divider_y - 34),
            (CANVAS_W / 2 + text_w / 2 + strip_pad, divider_y + 34),
        ],
        fill=(15, 15, 15),
    )
    _draw_outlined_text(
        draw, (CANVAS_W / 2, divider_y), with_text.upper(), badge_font,
        fill=(255, 214, 0), outline=(0, 0, 0), outline_width=3,
    )

    # --- "PART N" badge, bottom-left ---
    part_font = ImageFont.truetype(FONT_BADGE, 42)
    badge_xy = (70, CANVAS_H - 90)
    _draw_outlined_text(
        draw, badge_xy, part_label.upper(), part_font,
        fill=(120, 255, 120), outline=(0, 0, 0), outline_width=4, anchor="lm",
    )

    canvas.save(out_path)
    return out_path


def main():
    parser = argparse.ArgumentParser(description="Build a split-layout thumbnail like the reference screenshot.")
    parser.add_argument("--top-image", required=True)
    parser.add_argument("--bottom-image", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--with-text", default="WITH")
    parser.add_argument("--part-label", default="PART 2")
    parser.add_argument("--out", default="thumbnail.png")
    args = parser.parse_args()

    out = build_thumbnail(
        top_image=args.top_image,
        bottom_image=args.bottom_image,
        title=args.title,
        with_text=args.with_text,
        part_label=args.part_label,
        out_path=args.out,
    )
    print(f"Saved thumbnail to {out}")


if __name__ == "__main__":
    main()
