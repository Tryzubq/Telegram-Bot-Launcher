"""
bot.py
------
Run this from the command line:

    python bot.py

The bot listens on Telegram. Send it a video link (YouTube, TikTok, or
anything yt-dlp supports) and it will:
  1. Download it and send you back a preview, so you can see what you're
     working with
  2. Ask you to either reply `auto` (Gemini picks the best moments) or send
     your own timestamps
  3. Go through the resulting clips ONE AT A TIME — for each one, ask
     whether to use the AI-suggested title, type your own, or skip it —
     then cut, burn in the title, and send just that clip before moving on
     to the next
  4. Cut + crop each moment into a vertical clip in whichever format is set
     via CLIP_FORMAT (see .env / the launcher) — tiktok, square, facecam,
     or crop

Commands:
  /reset  - clear everything and start over
  /cancel - cancel whatever's currently running or pending
"""

import asyncio
import logging
import os
import re
import shutil
import threading
import uuid

from dotenv import load_dotenv

# Must run BEFORE importing clipper — clipper.py reads GEMINI_API_KEY etc.
# from the environment as soon as it's imported, so .env has to be loaded first.
load_dotenv()

from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from clipper import (
    Cancelled,
    ClipperError,
    LOCAL_VIDEO_EXTENSIONS,
    MAX_CLIPS,
    build_manual_clips,
    cut_clip,
    download_video,
    generate_quick_title,
    get_auto_clips,
    load_local_video,
    looks_like_local_video_path,
    parse_timestamps,
    resolve_format,
)

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
KEEP_FILES = os.environ.get("KEEP_FILES", "false").lower() == "true"

# The output format for this bot — set via .env / the launcher, not in Telegram.
CLIP_FORMAT = os.environ.get("CLIP_FORMAT", "tiktok")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("clipbot")

# Matches any http(s) link — yt-dlp itself decides whether it can actually
# handle the site, so we don't hardcode a YouTube-only pattern here.
URL_RE = re.compile(r"https?://\S+")

# chat_id -> state dict. Two shapes depending on where a chat is in the flow:
#   after download:      {"url", "job_id", "source_path", "duration"}
#   waiting on a title:  the above, plus {"clips", "index", "fmt", "facecam_box", "mode"}
PENDING: dict[int, dict] = {}

# chat_id -> threading.Event(), set while a download/analyze/cut job is running
# so /cancel can signal it to stop at the next safe checkpoint.
CANCEL_EVENTS: dict[int, threading.Event] = {}


def _cleanup_job(job_id: str):
    if not KEEP_FILES:
        shutil.rmtree(os.path.join("workdir", job_id), ignore_errors=True)


async def _send_video_with_retries(context, chat_id, video_path, caption, retries=2, **kwargs):
    """
    send_video wrapped with a couple of retries for transient network blips
    (dropped connections mid-upload are common on flaky connections,
    especially for larger files) before giving up and letting the caller
    handle the final failure.
    """
    last_error = None
    for attempt in range(retries + 1):
        try:
            with open(video_path, "rb") as f:
                return await context.bot.send_video(
                    chat_id=chat_id,
                    video=f,
                    caption=caption,
                    supports_streaming=True,
                    read_timeout=120,
                    write_timeout=180,
                    connect_timeout=30,
                    pool_timeout=120,
                    **kwargs,
                )
        except Exception as e:
            last_error = e
            if attempt < retries:
                await asyncio.sleep(2 * (attempt + 1))
    raise last_error


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Send me a video link (YouTube, TikTok, etc) or a local file path on this "
        "computer. I'll get it ready and show you a preview, then you can reply:\n"
        "Commands:\n"
        "/more - get more clips from the same video\n"
        "/reset - clear everything and start over\n"
        "/cancel - cancel whatever's currently running or pending",
    )


async def reset_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id

    event = CANCEL_EVENTS.get(chat_id)
    if event:
        event.set()

    pending = PENDING.pop(chat_id, None)
    if pending:
        _cleanup_job(pending["job_id"])

    await update.message.reply_text("🔄 Reset! Send a video link to start.")


async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    cancelled_something = False

    event = CANCEL_EVENTS.get(chat_id)
    if event:
        event.set()
        cancelled_something = True

    if chat_id in PENDING:
        pending = PENDING.pop(chat_id)
        _cleanup_job(pending["job_id"])
        cancelled_something = True

    if cancelled_something:
        await update.message.reply_text("❌ Cancelled.")
    else:
        await update.message.reply_text("Nothing to cancel right now.")


async def handle_link(update: Update, context: ContextTypes.DEFAULT_TYPE, url: str):
    chat_id = update.effective_chat.id
    job_id = uuid.uuid4().hex[:10]
    status_msg = await update.message.reply_text("Downloading…")

    cancel_event = threading.Event()
    CANCEL_EVENTS[chat_id] = cancel_event

    loop = asyncio.get_running_loop()

    def progress(msg: str):
        asyncio.run_coroutine_threadsafe(status_msg.edit_text(msg), loop)

    try:
        await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.UPLOAD_VIDEO)
        source_path, duration = await loop.run_in_executor(
            None, lambda: download_video(url, job_id, cancel_event=cancel_event, progress_cb=progress)
        )
    except Cancelled:
        await status_msg.edit_text("❌ Cancelled.")
        _cleanup_job(job_id)
        return
    except ClipperError as e:
        err_text = str(e)
        lower = err_text.lower()
        if any(s in lower for s in ("sign in", "not a bot", "confirm you", "page needs to be reloaded", "po token", "po_token")):
            tip = (
                "\n\nThis bot already tried 10 automatic download methods and YouTube "
                "blocked all of them — that means it specifically wants proof you're "
                "logged in. This is a one-time fix: in the Bot Launcher, use the "
                "\"Cookies file\" option (hover the ⓘ next to it for exact steps) — "
                "see the main README's \"Fixing YouTube download errors\" section for "
                "more detail."
            )
        else:
            tip = "\n\nTry other video."
        await status_msg.edit_text(f"Couldn't download that: {e}{tip}")
        return
    except Exception:
        log.exception("Download failed for %s", url)
        await status_msg.edit_text("Something went wrong downloading that link. Check the logs for details.\n\nTry other video.")
        return
    finally:
        CANCEL_EVENTS.pop(chat_id, None)

    await _preview_and_set_pending(update, context, chat_id, job_id, url, source_path, duration, status_msg)


async def handle_local_file(update: Update, context: ContextTypes.DEFAULT_TYPE, path: str):
    """
    Use a video file already sitting on this machine's disk directly,
    instead of downloading one. Since the bot runs locally, this has no
    size limit at all — unlike sending the file to the bot over Telegram,
    which is capped at ~20MB for bots receiving uploads.
    """
    chat_id = update.effective_chat.id
    job_id = uuid.uuid4().hex[:10]
    status_msg = await update.message.reply_text("Reading local file…")

    loop = asyncio.get_running_loop()
    try:
        source_path, duration = await loop.run_in_executor(None, lambda: load_local_video(path))
    except ClipperError as e:
        await status_msg.edit_text(f"Couldn't use that file: {e}\n\nTry other video.")
        return
    except Exception:
        log.exception("Local file read failed for %s", path)
        await status_msg.edit_text("Something went wrong reading that file. Check the logs for details.\n\nTry other video.")
        return

    await _preview_and_set_pending(update, context, chat_id, job_id, path, source_path, duration, status_msg)


TELEGRAM_BOT_DOWNLOAD_LIMIT_MB = 20  # Telegram's cap on files a bot can fetch directly


async def handle_file_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Someone attached a video/document directly in the chat instead of
    sending a link or typing a path. Telegram only lets bots download
    files up to ~20MB this way (a hard limit on Telegram's side, not
    something this code can raise) — since the bot runs on this same
    computer, anything bigger is better sent as a local file path instead,
    which has no size limit at all.
    """
    message = update.message
    file_obj = message.video or message.document
    if file_obj is None:
        return

    file_name = getattr(file_obj, "file_name", None) or "video"
    mime_type = getattr(file_obj, "mime_type", None) or ""
    ext = os.path.splitext(file_name)[1].lower()

    if message.document and not (mime_type.startswith("video/") or ext in LOCAL_VIDEO_EXTENSIONS):
        # Some other kind of document — not for us.
        return

    file_size = getattr(file_obj, "file_size", None) or 0
    size_mb = file_size / (1024 * 1024)
    chat_id = update.effective_chat.id

    if size_mb > TELEGRAM_BOT_DOWNLOAD_LIMIT_MB:
        await message.reply_text(
            f"That file is {size_mb:.1f}MB — Telegram only lets bots receive files up to "
            f"~{TELEGRAM_BOT_DOWNLOAD_LIMIT_MB}MB directly, regardless of what this bot does. "
            f"Since I'm running on this same computer, just send me the file's *path* instead "
            f"of the file itself — e.g. `C:\\Users\\you\\Downloads\\{file_name}` — no size limit that way.",
            parse_mode="Markdown",
        )
        return

    job_id = uuid.uuid4().hex[:10]
    status_msg = await message.reply_text("Downloading the file you sent…")

    try:
        tg_file = await context.bot.get_file(file_obj.file_id)
    except Exception as e:
        await status_msg.edit_text(
            f"Couldn't fetch that file from Telegram: {e}\n\n"
            f"Try sending the file's local path instead, e.g. `C:\\Users\\you\\Downloads\\{file_name}`.",
            parse_mode="Markdown",
        )
        return

    local_dir = os.path.join("workdir", job_id)
    os.makedirs(local_dir, exist_ok=True)
    local_path = os.path.join(local_dir, f"uploaded{ext or '.mp4'}")

    try:
        await tg_file.download_to_drive(local_path)
    except Exception:
        log.exception("Failed to save uploaded file for job %s", job_id)
        await status_msg.edit_text("Something went wrong saving that file. Check the logs for details.\n\nTry other video.")
        return

    loop = asyncio.get_running_loop()
    try:
        source_path, duration = await loop.run_in_executor(None, lambda: load_local_video(local_path))
    except ClipperError as e:
        await status_msg.edit_text(f"Couldn't use that file: {e}\n\nTry other video.")
        return
    except Exception:
        log.exception("Uploaded file read failed for job %s", job_id)
        await status_msg.edit_text("Something went wrong reading that file. Check the logs for details.\n\nTry other video.")
        return

    await _preview_and_set_pending(update, context, chat_id, job_id, file_name, source_path, duration, status_msg)


async def _preview_and_set_pending(update, context, chat_id, job_id, source_ref, source_path, duration, status_msg):
    """Shared by handle_link and handle_local_file: send a preview (if it fits Telegram's
    upload cap) and mark this chat's pending state as ready for auto/timestamps."""
    size_mb = os.path.getsize(source_path) / (1024 * 1024)
    PENDING[chat_id] = {"url": source_ref, "job_id": job_id, "source_path": source_path, "duration": duration}

    caption = (
        f"✅ Downloaded ({size_mb:.1f}MB, {duration:.0f}s)\n\n"
        f"Send timestamps, e.g. `0-{min(duration, 60):.0f}`, reply `auto` to let AI pick "
        f"the best moments (you'll choose a title for each), or `auto all` to get all "
        f"{MAX_CLIPS} clips right away with AI titles already applied — no extra questions."
    )

    # Telegram's Bot API caps file uploads from bots at ~50MB — a preview
    # above that is essentially guaranteed to fail or hang, so don't even
    # attempt it; just say so plainly and let the user carry on straight away.
    if size_mb > 45:
        await status_msg.edit_text(
            f"{caption}\n\n(No video preview — the file is {size_mb:.0f}MB, "
            f"over Telegram's ~50MB upload limit for bots. The final clips "
            f"will be much smaller and will preview normally.)",
            parse_mode="Markdown",
        )
        return

    await status_msg.edit_text(f"Uploading preview ({size_mb:.1f}MB)…")
    try:
        await _send_video_with_retries(
            context, chat_id, source_path, caption=caption, parse_mode="Markdown"
        )
    except Exception:
        # The source itself is ready and PENDING is already set above, so
        # the user can carry on (reply `auto` or timestamps) even if just the
        # preview upload timed out — no need to lose their progress over it.
        log.exception("Preview upload timed out/failed for %s", source_ref)
        await status_msg.edit_text(caption, parse_mode="Markdown")
        return
    await status_msg.delete()


async def _run_auto_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, pending: dict, auto_apply_titles: bool = False):
    loop = asyncio.get_running_loop()
    cancel_event = threading.Event()
    CANCEL_EVENTS[chat_id] = cancel_event

    status_msg = await update.message.reply_text("Starting analysis…")

    def progress(msg: str):
        asyncio.run_coroutine_threadsafe(status_msg.edit_text(msg), loop)

    exclude_ranges = pending.get("used_ranges", [])

    try:
        clips = await loop.run_in_executor(
            None,
            lambda: get_auto_clips(
                pending["source_path"], pending["duration"], pending["job_id"], progress, cancel_event,
                exclude_ranges=exclude_ranges,
            ),
        )
        fmt, facecam_box = await loop.run_in_executor(
            None,
            lambda: resolve_format(pending["source_path"], pending["duration"], CLIP_FORMAT, progress),
        )
    except Cancelled:
        await status_msg.edit_text("❌ Cancelled.")
        _cleanup_job(pending["job_id"])
        PENDING.pop(chat_id, None)
        return
    except ClipperError as e:
        await status_msg.edit_text(f"Couldn't finish that one: {e}")
        return
    except Exception:
        log.exception("Auto analysis failed for %s", pending.get("url"))
        await status_msg.edit_text("Something went wrong analyzing that video. Check the logs for details.")
        return
    finally:
        CANCEL_EVENTS.pop(chat_id, None)

    if not clips:
        await status_msg.edit_text("Gemini didn't return any usable clips for this video.")
        return

    if auto_apply_titles:
        # "auto all" — skip the per-clip title prompt entirely: cut and send
        # every clip immediately, each with Gemini's own suggested title.
        await status_msg.edit_text(f"Found {len(clips)} clip(s) — cutting all with AI titles applied…")
        sent_count = 0
        for i, clip in enumerate(clips, start=1):
            title = clip.title
            try:
                clip_path = await loop.run_in_executor(
                    None,
                    lambda c=clip, idx=i: cut_clip(pending["source_path"], c, pending["job_id"], idx, fmt=fmt, facecam_box=facecam_box),
                )
            except ClipperError as e:
                await update.effective_chat.send_message(f"Couldn't finish clip {i}: {e}")
                continue
            except Exception:
                log.exception("Cutting clip %d failed for job %s", i, pending["job_id"])
                await update.effective_chat.send_message(f"Something went wrong cutting clip {i}. Check the logs for details.")
                continue

            cap = f"#{i}/{len(clips)}" + (f" {title}" if title else "")
            try:
                await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.UPLOAD_VIDEO)
                await _send_video_with_retries(context, chat_id, clip_path, caption=cap)
                sent_count += 1
            except Exception:
                log.exception("Failed to send clip #%d for job %s", i, pending["job_id"])
                await update.effective_chat.send_message(f"Clip #{i} finished but failed to upload after retries — you may want to try again.")

        used_ranges = pending.get("used_ranges", []) + [(c.start, c.end) for c in clips]
        PENDING[chat_id] = {
            "url": pending["url"],
            "job_id": pending["job_id"],
            "source_path": pending["source_path"],
            "duration": pending["duration"],
            "used_ranges": used_ranges,
        }
        if sent_count == len(clips):
            done_line = f"✅ Done! All {len(clips)} clip(s) sent."
        elif sent_count > 0:
            done_line = f"⚠️ Done — {sent_count}/{len(clips)} clip(s) sent, the rest hit errors above."
        else:
            done_line = "❌ None of those clips made it through — see the errors above."
        await update.effective_chat.send_message(
            f"{done_line}\n\n"
            f"Send more timestamps, reply `auto`/`auto all` again, or use /more for another "
            f"{MAX_CLIPS} AI-picked clips — same video, no need to resend the link.",
            parse_mode="Markdown",
        )
        return

    pending["clips"] = clips
    pending["index"] = 0
    pending["sent_count"] = 0
    pending["mode"] = "auto"
    pending["fmt"] = fmt
    pending["facecam_box"] = facecam_box

    await status_msg.edit_text(f"Found {len(clips)} clip(s)!")
    await _send_next_prompt(update, context, chat_id)


async def more_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    pending = PENDING.get(chat_id)
    if not pending or "source_path" not in pending:
        await update.message.reply_text("Send me a video link first.")
        return
    if "clips" in pending:
        await update.message.reply_text("Finish choosing titles for the current clips first.")
        return
    await _run_auto_flow(update, context, chat_id, pending)


def _title_prompt_text(pending: dict) -> str:
    i = pending["index"]
    n = len(pending["clips"])
    clip = pending["clips"][i]
    header = f"Clip {i + 1}/{n}"

    if pending["mode"] == "auto" and clip.title:
        header += f' — AI suggests: "{clip.title}"'
        if clip.reason:
            header += f"\n{clip.reason} (score {clip.score}/10)"
    else:
        header += f" ({clip.start:.0f}s–{clip.end:.0f}s)"

    return (
        f"{header}\n\n"
        "Reply with your own title, `auto` to generate/use an AI title, "
        "or `skip` for no title."
    )


async def _send_next_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int):
    pending = PENDING[chat_id]
    await context.bot.send_message(chat_id=chat_id, text=_title_prompt_text(pending), parse_mode="Markdown")


async def _process_current_clip(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, title_choice: str):
    pending = PENDING[chat_id]
    i = pending["index"]
    clips = pending["clips"]
    clip = clips[i]
    loop = asyncio.get_running_loop()

    status_msg = await update.message.reply_text(f"Working on clip {i + 1}/{len(clips)}…")

    choice = title_choice.strip()
    if choice.lower() == "skip":
        chosen_title = ""
    elif choice.lower() == "auto":
        if pending["mode"] == "auto" and clip.title:
            chosen_title = clip.title
        else:
            await status_msg.edit_text(f"Generating a title with AI for clip {i + 1}/{len(clips)}…")
            chosen_title = await loop.run_in_executor(
                None,
                lambda: generate_quick_title(pending["source_path"], clip.start, clip.end, pending["job_id"]),
            )
    else:
        chosen_title = choice[:60]

    clip.title = chosen_title

    await status_msg.edit_text(f"Cutting clip {i + 1}/{len(clips)}…")
    try:
        clip_path = await loop.run_in_executor(
            None,
            lambda: cut_clip(
                pending["source_path"], clip, pending["job_id"], i + 1,
                fmt=pending["fmt"], facecam_box=pending["facecam_box"],
            ),
        )
    except ClipperError as e:
        await status_msg.edit_text(f"Couldn't finish clip {i + 1}: {e}")
    except Exception:
        log.exception("Cutting clip %d failed for job %s", i + 1, pending["job_id"])
        await status_msg.edit_text(f"Something went wrong cutting clip {i + 1}. Check the logs for details.")
    else:
        await status_msg.edit_text(f"Uploading clip {i + 1}/{len(clips)}…")
        if pending["mode"] == "auto":
            cap = f"#{i + 1}/{len(clips)}" + (f" {chosen_title}" if chosen_title else "")
        else:
            cap = f"#{i + 1}/{len(clips)} {clip.start:.0f}s–{clip.end:.0f}s" + (f" — {chosen_title}" if chosen_title else "")
        try:
            await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.UPLOAD_VIDEO)
            await _send_video_with_retries(context, chat_id, clip_path, caption=cap)
            await status_msg.delete()
            pending["sent_count"] = pending.get("sent_count", 0) + 1
        except Exception:
            log.exception("Failed to send clip #%d for job %s", i + 1, pending["job_id"])
            await status_msg.edit_text(f"Clip #{i + 1} finished but failed to upload after retries — you may want to try again.")

    pending["index"] += 1
    if pending["index"] < len(clips):
        await _send_next_prompt(update, context, chat_id)
    else:
        sent_count = pending.get("sent_count", 0)
        used_ranges = pending.get("used_ranges", []) + [(c.start, c.end) for c in clips]
        # Keep the download around instead of cleaning up — the user can
        # immediately send more timestamps, reply `auto` again, or use
        # /more, without having to resend the link and re-download.
        PENDING[chat_id] = {
            "url": pending["url"],
            "job_id": pending["job_id"],
            "source_path": pending["source_path"],
            "duration": pending["duration"],
            "used_ranges": used_ranges,
        }
        if sent_count == len(clips):
            done_line = f"✅ Done! All {len(clips)} clip(s) sent."
        elif sent_count > 0:
            done_line = f"⚠️ Done — {sent_count}/{len(clips)} clip(s) sent, the rest hit errors above."
        else:
            done_line = "❌ None of those clips made it through — see the errors above."
        await update.effective_chat.send_message(
            f"{done_line}\n\n"
            f"Send more timestamps, reply `auto` again, or use /more for another "
            f"{MAX_CLIPS} AI-picked clips — same video, no need to resend the link.",
            parse_mode="Markdown",
        )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    chat_id = update.effective_chat.id

    url_match = URL_RE.search(text)
    if url_match:
        # A fresh link always replaces any pending video for this chat.
        await handle_link(update, context, url_match.group(0))
        return

    if looks_like_local_video_path(text):
        # A local file path — the video already lives on this machine's
        # disk, so this also always replaces any pending video for this chat.
        await handle_local_file(update, context, text)
        return

    pending = PENDING.get(chat_id)
    if not pending:
        await update.message.reply_text("Send me a video link (or a local file path on this computer) to get started.")
        return

    # Already past download and into the "choose a title for this clip" stage.
    if "clips" in pending:
        await _process_current_clip(update, context, chat_id, text)
        return

    if text.lower() in ("auto all", "autoall", "auto-all"):
        await _run_auto_flow(update, context, chat_id, pending, auto_apply_titles=True)
        return

    if text.lower() == "auto":
        await _run_auto_flow(update, context, chat_id, pending)
        return

    loop = asyncio.get_running_loop()
    cancel_event = threading.Event()
    CANCEL_EVENTS[chat_id] = cancel_event

    ranges = parse_timestamps(text)
    if ranges:
        clips = build_manual_clips(ranges, pending["duration"])
        if not clips:
            await update.message.reply_text("None of those timestamp ranges fit inside the video's duration.")
            return

        status_msg = await update.message.reply_text("Getting ready…")
        try:
            fmt, facecam_box = await loop.run_in_executor(
                None,
                lambda: resolve_format(pending["source_path"], pending["duration"], CLIP_FORMAT, None),
            )
        finally:
            CANCEL_EVENTS.pop(chat_id, None)

        pending["clips"] = clips
        pending["index"] = 0
        pending["sent_count"] = 0
        pending["mode"] = "manual"
        pending["fmt"] = fmt
        pending["facecam_box"] = facecam_box

        await status_msg.delete()
        await _send_next_prompt(update, context, chat_id)
        return

    CANCEL_EVENTS.pop(chat_id, None)
    await update.message.reply_text(
        "I didn't catch that. Reply `auto`, or timestamps like `0:10-0:45, 1:20-2:00`.",
        parse_mode="Markdown",
    )


def main():
    if not TELEGRAM_BOT_TOKEN:
        raise SystemExit("TELEGRAM_BOT_TOKEN is not set. Copy .env.example to .env and fill it in.")
    if not os.environ.get("GEMINI_API_KEY"):
        raise SystemExit("GEMINI_API_KEY is not set. Copy .env.example to .env and fill it in.")

    app = (
        Application.builder()
        .token(TELEGRAM_BOT_TOKEN)
        .read_timeout(60)
        .write_timeout(120)
        .connect_timeout(30)
        .pool_timeout(60)
        .build()
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("more", more_cmd))
    app.add_handler(CommandHandler("reset", reset_cmd))
    app.add_handler(CommandHandler("cancel", cancel_cmd))
    app.add_handler(MessageHandler(filters.VIDEO | filters.Document.ALL, handle_file_upload))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    log.info("Bot is running (format=%s). Press Ctrl+C to stop.", CLIP_FORMAT)
    app.run_polling()


if __name__ == "__main__":
    main()
