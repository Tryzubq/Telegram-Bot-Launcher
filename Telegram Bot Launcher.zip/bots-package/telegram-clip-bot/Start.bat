@echo off
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py launcher.py
) else (
    python launcher.py
)

if errorlevel 1 (
    echo.
    echo Something went wrong. Make sure Python is installed and on PATH.
    echo Try running "py -0p" in Command Prompt to see which Python versions are installed.
    pause
)
