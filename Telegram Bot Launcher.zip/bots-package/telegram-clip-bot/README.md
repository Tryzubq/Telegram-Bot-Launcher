# Telegram Clip Bot

Runs from your command line (or with a simple Start button — see below).
Send it a video link and it downloads the video, has **Gemini** watch it
to find the best short-form moments, then cuts + crops each one to a
vertical clip (TikTok/Shorts, Square 1:1, or Facecam split — configurable,
see below) and sends them back to you in the chat.

## Easiest way to run it: the Start button

1. Double-click **`Start.bat`** (Windows) or **`Start.sh`** (Mac/Linux) —
   or run `python launcher.py` yourself.
2. Pick which bot to run from the dropdown — **Clip & Caption Bot** (this
   folder) or **Video Rater Bot** (your separate ranking bot, if you point
   it at that folder with "Browse…").
3. Click **📦 Install Requirements** once per bot — this creates a private,
   isolated environment inside that bot's own folder (a `.venv` subfolder)
   and installs its `requirements.txt` into *that*, not your system Python.
   This means installing one bot's dependencies can never downgrade or
   break the other bot's — they used to share one global Python environment,
   which caused real conflicts (an older library one bot needed would
   silently break a newer one the other bot needed).
4. Paste in that bot's **Telegram Bot Token** and **Gemini API Key** — hover
   the ⓘ next to each field if you need a reminder of where to get it. When
   Clip & Caption Bot is selected, **Output format** and **Background**
   dropdowns also appear (TikTok/Shorts 9:16, 4:3, Square, or Facecam
   split; and Blur/Dark Blur/Black/White padding) — this is where you set
   these now, instead of a per-video button in Telegram.
5. Press **▶ Start Bot**. It saves the keys (and format) into that bot's own
   `.env` file and launches it using that same isolated environment, with a
   live log in the window. **■ Stop Bot** shuts it down again.

Switching the dropdown between bots never loses anything — whatever's typed
in the folder/token/key fields is kept in memory per bot, even before you
press Start, so you can flip back and forth freely while setting both up.

**Do you still need the `.env` file if you're using the launcher?** Yes —
it's still there and it's still what the bot actually reads at startup
(via `python-dotenv`). You just don't have to open or edit it by hand
anymore: the launcher writes your two keys into it for you every time you
press Start. Only touch `.env` directly if you want to tweak the optional
settings below it (`MAX_CLIPS`, etc.) — those aren't in the launcher window.

You only need to paste the keys in once per bot — they're remembered for
next time you open the launcher.

**Who can use the bot once it's running?** Anyone who messages it on
Telegram — the bot isn't limited to you. Every chat is tracked
independently by its own Telegram chat ID, so multiple people can use it
at the same time without interfering with each other's downloads or clips.
Just share your bot's @username with whoever you want to have access (or
keep it to yourself by not sharing it).

## Running the Video Rater Bot from the same launcher

If you have a separate "Video Rater Bot" project (the ranking/countdown
bot with `config.py`, `video_processor.py`, etc.), you don't need a second
launcher — this one runs it too:

1. Open the launcher, switch the dropdown to **Video Rater Bot**.
2. Click **Browse…** and select that project's folder (the one with its
   own `bot.py` in it).
3. Click **📦 Install Requirements** to install its dependencies (it uses
   moviepy and different packages than this bot).
4. Paste in its Telegram token and Gemini key. A **"Blur background behind
   square clips"** checkbox also appears — this replaces the plain black
   bar behind square clips with a blurred, zoomed copy of the video
   (CapCut-style), matching the same look as this bot's Square format.
5. Press Start.

The launcher remembers each bot's folder and keys separately, so switching
back and forth just works. That project also has its own `fix_moviepy.py`
patch step if you're on Pillow 10+ — run that once first if you haven't
already (the Install Requirements button doesn't run this for you, since
it's a one-off code patch rather than a package to install).

## 1. Install requirements

You need **Python 3.10+** and **ffmpeg** installed on your machine.

```bash
# ffmpeg (Windows: winget install ffmpeg | Mac: brew install ffmpeg | Linux: apt install ffmpeg)
pip install -r requirements.txt
```

> Linux only: the Start button uses Tkinter for its window. If
> `python3 launcher.py` complains it's missing, install it with
> `sudo apt install python3-tk` (Windows/Mac already include it with Python).

## 2. Get your two keys

- **Telegram Bot Token** — message [@BotFather](https://t.me/BotFather) on
  Telegram, run `/newbot`, and paste the token it gives you.
- **Gemini API Key** — grab a free key from
  [Google AI Studio](https://aistudio.google.com/apikey).

Paste both into the launcher window (above), **or** skip the launcher and
put them straight into a `.env` file yourself:

```bash
cp .env.example .env
# then edit .env with your values
```

## 3. Run it

Either double-click `Start.bat` / `Start.sh`, or from the command line:

```bash
python bot.py
```

Open a chat with your bot on Telegram, send `/start`, then paste a video link.

**Commands:**
- `/more` — get another batch of AI-picked clips from the same video, without resending the link
- `/reset` — clear everything and start fresh
- `/cancel` — cancel whatever's currently downloading, analyzing, or cutting

## How it works

1. **Download & preview** — send any video link (YouTube, TikTok, etc. — 
   anything `yt-dlp` supports), **or a local file path** on this same
   computer (e.g. `C:\Users\you\Downloads\video.mkv`) — useful for files
   you already have, since it has no size limit at all (unlike sending the
   file to the bot over Telegram, which caps uploads to bots at ~20MB).
   For a link, the bot downloads it (capped at 1080p and at
   `MAX_SOURCE_DURATION_SEC`, default 1 hour); for a local file, it's read
   directly, never copied or modified. Either way you get a preview sent
   back with its size and duration, so you can see exactly what you're
   about to clip. If the file is over ~45MB, Telegram's ~50MB bot upload
   cap means there's no preview — you just get a text confirmation
   instead, and can carry on straight away.
2. **Pick clips** — reply with either:
   - `auto` — the whole video is uploaded to Gemini's File API, and Gemini
     returns the top N moments (start/end timestamps, a title, a one-line
     reason, and a 1-10 "virality score") as JSON. These are stretched to
     at least `CLIP_MIN_SEC` (default 60s) if Gemini picked something
     shorter. You'll then be asked for a title for each one (see step 3), **or**
   - `auto all` — same AI clip-picking, but skips the per-clip title
     question entirely: all clips are cut and sent right away, each with
     Gemini's own suggested title already applied, **or**
   - your own timestamps, e.g. `0:10-0:45, 1:20-2:00` — cut exactly as
     given, no minimum length — a 5-second manual clip stays 5 seconds.
3. **One clip at a time** (skipped entirely for `auto all`) — for each clip,
   the bot asks: reply with your own
   title, `auto` to use (or generate, for manual-timestamp clips) an
   AI title, or `skip` for no title. Only after you answer does it cut that
   one clip, burn in the title — bigger, bold italic, centered both
   horizontally and vertically within the padding zone above the video
   (not just pinned near the top), white with a black outline (or the
   reverse on a white background, so it's never invisible), wrapping (or
   truncating with "…") if too long — and send it, before moving on to
   prompt for the next one. Every step (downloading, indexing, cutting,
   uploading) posts a status message, so it's always clear the bot is
   working rather than stuck.
4. **Done, but not really done** — once every clip's been through that, you
   get a "✅ Done!" message, but the download is kept around: send more
   timestamps, reply `auto` again, or use `/more` for another batch of
   AI picks — no need to resend the link. `auto`/`/more` tell Gemini which
   time ranges were already used so it picks genuinely new moments each
   time. The download is only cleaned up on `/reset`, `/cancel`, or once
   you send a fresh link.

### Output format

`CLIP_FORMAT` in `.env` — set via the dropdown in the launcher, not in
Telegram — controls every clip this bot makes:

- **`tiktok`** ("Fullscreen (9:16)") — the full frame is preserved (nothing
  cropped off the sides), with the padding style below filling the space
  above/below.
- **`aspect43`** ("4:3 Aspect") — a centered 4:3 crop, same padding above/below.
- **`square`** ("Square (1:1)") — a centered square 1:1 crop, same padding.
- **`facecam`** ("Facecam Gameplay") — for gaming/reaction videos with a
  small webcam inset: Gemini looks at a frame and tries to find the
  facecam, then stacks it on top (~32% of the frame) with the main footage
  below (~68%). Best-effort — if no facecam is found, it automatically
  falls back to `tiktok`. No padding zone, so the background style below
  doesn't apply to this one.

### Background style

`BG_STYLE` in `.env` — also set via the launcher, right below the format
dropdown — controls what fills the padding zone for `tiktok`/`aspect43`/`square`:

- **`blur`** (default) — a blurred, zoomed copy of the video itself, CapCut-style.
- **`darkblur`** — the same blur, additionally darkened for stronger title contrast.
- **`black`** — a plain solid black bar, not derived from the video at all.
- **`white`** — a plain solid white bar. The title automatically switches
  to black-fill/white-outline against this one, since white-on-white
  would otherwise be invisible.

To change either, use the launcher's dropdowns and restart the bot.

### Why "auto" can be slow for long videos

When you reply `auto`, the video first gets uploaded to Gemini and Gemini
has to index the whole thing before it can find anything — and that
indexing step runs at roughly **real-time speed relative to the video's
length**. A 20-minute video takes roughly 20 minutes just to become
"ready," before Gemini even starts picking clips. That's a limit of
Gemini's File API itself, not something in this code.

What the bot already does to help:
- It uploads a downscaled 480p copy for analysis (the final clips are still
  cut from the original full-quality file) — this cuts upload time, though
  not Gemini's own indexing time.
- It shows elapsed-time progress messages while waiting, so you can see
  it's actually working.

What you can do:
- For long videos, use **manual timestamps instead of `auto`** — it skips
  Gemini's indexing step completely and is effectively instant.
- Keep `auto` for shorter clips (under ~10 min) if you want the AI pick
  and a short wait.

## Thumbnail generator (`thumbnail_maker.py`)

A separate CLI tool that builds a split-layout thumbnail — title banner on
top, your photo, a "WITH" divider, a second photo, and a "PART N" badge in
the corner — the same structure as a typical viral-clip thumbnail, run
independently of the Telegram bot:

```bash
python thumbnail_maker.py \
  --top-image me.jpg \
  --bottom-image guest.jpg \
  --title "Putting a 10ft Alligator in My Pool & Hiring a Pool Guy!" \
  --with-text "WITH" \
  --part-label "PART 2" \
  --out thumbnail.png
```

It uses two bundled open-license display fonts (`assets/fonts/`) — Big
Shoulders Bold for the title, Boldonse for the "WITH"/"PART N" badges —
intentionally different from the neon rounded font in the reference
screenshot. To match a specific font exactly, drop a `.ttf` into
`assets/fonts/` and point `FONT_TITLE` / `FONT_BADGE` at it near the top of
`thumbnail_maker.py`.

This isn't wired into the Telegram bot yet (collecting two photos through
chat needs a small multi-step conversation flow) — say the word if you want
that added as a `/thumbnail` bot command.

## Tuning (in `.env`)

| Variable | What it does |
|---|---|
| `CLIP_FORMAT` | Output format: `tiktok` / `aspect43` / `square` / `facecam` — set via the launcher's dropdown, or here directly |
| `BG_STYLE` | Padding style behind the video/crop: `blur` / `darkblur` / `black` / `white` — set via the launcher's dropdown, or here directly |
| `MAX_CLIPS` | How many clips to generate per video (default 5) |
| `CLIP_MIN_SEC` / `CLIP_MAX_SEC` | Allowed clip length range for `auto`/`/more` picks only (default 60-90s). Manual timestamp clips are never stretched — they're cut exactly as given. |
| `MAX_SOURCE_DURATION_SEC` | Longest source video the bot will accept |
| `GEMINI_MODEL` | Swap models — defaults to `gemini-3.6-flash` (fast/cheap); use a Pro model for better judgment at higher cost/latency |
| `KEEP_FILES` | Set `true` to keep downloaded/cut files in `workdir/` instead of deleting them after sending |

## About the NVIDIA mention

This build uses Gemini for clip selection since it can directly watch the
uploaded video. Swapping in an NVIDIA NIM model would mean either (a) using
a NIM vision-language model that accepts video/frames, or (b) transcribing
audio first (e.g. Whisper) and having a NIM-hosted LLM pick clips from the
transcript + timestamps only, without actually watching the footage. Happy
to build that path too if you want a second "brain" option — it would slot
into `clipper.py` as an alternative to `analyze_video()`.

## Notes / limits

- **Copyright**: this is built for clipping content you own or have the
  rights to reuse (your own uploads, licensed footage, stuff you have
  permission for). Downloading and redistributing copyrighted YouTube videos
  or movies can violate YouTube's Terms of Service and copyright law —
  that's on you to make sure you're clear on before running it against
  someone else's content.
- Gemini's File API has its own size/duration limits and per-minute/day
  quotas on the free tier — long videos or heavy use may need a paid key.
- Facecam detection is Gemini's best guess from a single frame, not a
  dedicated computer-vision model — works well for a clear, static webcam
  box; unusual layouts may miss and fall back to the `tiktok` format.
- **"Sign in to confirm you're not a bot" / "page needs to be reloaded"
  errors from YouTube**: this is YouTube's own anti-bot check on certain
  videos, not a bug in the bot — it can happen to any yt-dlp-based tool.
  The bot already retries 10 different automatic methods first, at no
  cost; if all 10 are still blocked, use the **Cookies file** option in
  the Bot Launcher (hover the ⓘ next to it) — see the main project
  README's "Fixing YouTube download errors" section for full steps.
- **No preview for very large source videos**: Telegram's Bot API caps
  uploads from bots at roughly 50MB. A download over ~45MB skips the
  preview step entirely (rather than trying and hanging) and just confirms
  the download succeeded — the final clips are still cut normally and are
  almost always well under that limit, so they preview fine. This matters
  a lot for `MAX_SOURCE_DURATION_SEC`: 1080p video runs roughly 15-40MB
  per minute depending on content, so a full hour-long download can easily
  land in the 400MB+ range.
  For uploads to bypass the 50MB cap entirely (not just the preview —
  every upload, including final clips), Telegram supports running your
  own local Bot API server (raises the cap to 2GB), which needs an
  `api_id`/`api_hash` from https://my.telegram.org and the official
  `telegram-bot-api` server binary — a bigger setup than anything else
  here, so ask if you want to go that route.
- Uploads (previews and clips) retry automatically up to twice on
  transient network errors before giving up.
