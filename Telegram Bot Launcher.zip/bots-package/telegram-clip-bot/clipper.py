"""
clipper.py
----------
Download a YouTube video, have Gemini watch it and pick the best short-form
moments, then cut + crop those moments into vertical (9:16) clips with ffmpeg.
"""

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
import uuid
from dataclasses import dataclass

import yt_dlp
from google import genai
from PIL import Image, ImageDraw, ImageFont

log = logging.getLogger(__name__)

GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")

MAX_SOURCE_DURATION_SEC = int(os.environ.get("MAX_SOURCE_DURATION_SEC", 60 * 60))  # 1 hour cap
MAX_CLIPS = int(os.environ.get("MAX_CLIPS", 5))
CLIP_MIN_SEC = int(os.environ.get("CLIP_MIN_SEC", 60))
CLIP_MAX_SEC = int(os.environ.get("CLIP_MAX_SEC", 90))

DEFAULT_FORMAT = os.environ.get("CLIP_FORMAT", "tiktok")  # tiktok | square | aspect43 | facecam
BG_STYLE = os.environ.get("BG_STYLE", "blur")  # blur | darkblur | black | white

# Burns auto-generated captions onto every clip using local speech-to-text
# (faster-whisper) — no API key, no per-clip cost, nothing sent anywhere.
# The whisper model itself (~250MB) downloads once on first use and is
# cached afterward.
SUBTITLES_ENABLED = os.environ.get("SUBTITLES_ENABLED", "false").strip().lower() in ("1", "true", "yes", "on")
SUBTITLE_FONT_SIZE = 56

# Fixes "Sign in to confirm you're not a bot" errors from YouTube on some
# videos — set one of these in .env if you hit that. COOKIES_FROM_BROWSER
# is a browser name yt-dlp will pull cookies from directly (e.g. "chrome",
# "firefox", "edge" — that browser must be installed on this machine and
# have been used to log into YouTube at some point). COOKIES_FILE is a
# path to a cookies.txt file exported via a browser extension, used only
# if COOKIES_FROM_BROWSER isn't set.
COOKIES_FROM_BROWSER = os.environ.get("COOKIES_FROM_BROWSER", "").strip()
COOKIES_FILE = os.environ.get("COOKIES_FILE", "").strip()

WORK_DIR = os.environ.get("WORK_DIR", "workdir")

CANVAS_W, CANVAS_H = 1080, 1920
FACECAM_ZONE_H = 680   # ~35% — facecam on top, cover-cropped, no blur on its sides
GAMEPLAY_ZONE_H = CANVAS_H - FACECAM_ZONE_H  # ~65% — gameplay below, cover-cropped, title burned on top of it

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "assets", "fonts")
TITLE_FONT = os.path.join(ASSETS_DIR, "PoppinsBoldItalic.ttf")
TITLE_FONT_SIZE = 88

_whisper_model = None


def _get_whisper_model():
    """Lazily load (and cache) the local speech-to-text model, once per bot run."""
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel
        _whisper_model = WhisperModel("small", device="cpu", compute_type="int8")
    return _whisper_model


def _transcribe_clip_audio(source_path: str, start: float, end: float) -> list[tuple[float, float, str]]:
    """
    Run local speech-to-text on [start, end] of source_path and return a
    list of (seg_start, seg_end, text) tuples with timestamps relative to
    the clip itself (0 = the clip's first frame) — ready to hand straight
    to the overlay timing below. Never raises; returns [] on any failure
    so a transcription hiccup skips subtitles rather than failing the clip.
    """
    audio_path = os.path.join(tempfile.gettempdir(), f"clipbot_subaudio_{uuid.uuid4().hex[:10]}.wav")
    try:
        extract = subprocess.run(
            ["ffmpeg", "-y", "-ss", f"{start:.3f}", "-to", f"{end:.3f}", "-i", source_path,
             "-vn", "-ac", "1", "-ar", "16000", audio_path],
            capture_output=True, text=True,
        )
        if extract.returncode != 0 or not os.path.exists(audio_path):
            log.warning("Subtitle audio extraction failed: %s", extract.stderr[-300:])
            return []
        model = _get_whisper_model()
        segments, _ = model.transcribe(audio_path, beam_size=1, vad_filter=True)
        return [(seg.start, seg.end, seg.text.strip()) for seg in segments if seg.text.strip()]
    except Exception:
        log.exception("Subtitle transcription failed")
        return []
    finally:
        if os.path.exists(audio_path):
            try:
                os.remove(audio_path)
            except OSError:
                pass



@dataclass
class Clip:
    start: float
    end: float
    title: str
    reason: str
    score: float


class ClipperError(Exception):
    pass


class Cancelled(ClipperError):
    """Raised when a user cancels a job in progress via /cancel or /reset."""
    pass


def _check_cancelled(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise Cancelled("Cancelled by user.")


def _job_dir(job_id: str) -> str:
    # Absolute, always — this gets embedded in ffmpeg filter graph strings
    # (drawtext's textfile=), and a relative path there is resolved against
    # whatever ffmpeg's own working directory happens to be at the moment
    # it's spawned. That can silently differ from what Python assumes
    # depending on how the process was launched (venv, GUI launcher,
    # thread pool, etc.), so relative paths there are fragile — always use
    # absolute ones for anything that ends up inside a filter string.
    path = os.path.abspath(os.path.join(WORK_DIR, job_id))
    os.makedirs(path, exist_ok=True)
    return path


def download_video(url: str, job_id: str, cancel_event=None, progress_cb=None) -> tuple[str, float]:
    """Download a YouTube video with yt-dlp. Returns (filepath, duration_sec)."""
    out_dir = _job_dir(job_id)
    out_template = os.path.join(out_dir, "source.%(ext)s")

    last_notify = [0.0]

    def _hook(d):
        if cancel_event is not None and cancel_event.is_set():
            raise yt_dlp.utils.DownloadError("Cancelled by user.")

        if not progress_cb:
            return

        now = time.time()
        status = d.get("status")
        if status == "downloading":
            # Throttled — yt-dlp fires this many times a second, and Telegram
            # rate-limits how often a message can be edited.
            if now - last_notify[0] < 3:
                return
            last_notify[0] = now
            percent = (d.get("_percent_str") or "").strip()
            speed = (d.get("_speed_str") or "").strip()
            eta = (d.get("_eta_str") or "").strip()
            bits = [b for b in [percent, speed and f"at {speed}", eta and f"ETA {eta}"] if b]
            progress_cb("Downloading… " + (", ".join(bits) if bits else "in progress"))
        elif status == "finished":
            progress_cb("Download finished — finalizing…")

    def base_opts() -> dict:
        opts = {
            "format": "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
            "outtmpl": out_template,
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "progress_hooks": [_hook],
        }
        # YouTube (and some other sites) can throw a "Sign in to confirm
        # you're not a bot" error on certain videos — this is YouTube's own
        # anti-bot check, not a bug here. Cookies from a real logged-in
        # browser session are one workaround, if configured.
        if COOKIES_FROM_BROWSER:
            opts["cookiesfrombrowser"] = (COOKIES_FROM_BROWSER,)
        elif COOKIES_FILE:
            opts["cookiefile"] = COOKIES_FILE
        return opts

    def is_bot_check_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return (
            "sign in" in msg or "not a bot" in msg or "confirm you" in msg
            # YouTube's other common way of saying the same thing — a
            # failed/missing session-verification token, phrased as if the
            # page itself is stale rather than as an explicit login wall.
            or "page needs to be reloaded" in msg or "po token" in msg or "po_token" in msg
        )

    # The bot-check error above doesn't happen on every YouTube "client" —
    # yt-dlp can pretend to be YouTube's Android, iOS, TV, or various web
    # embed contexts instead of a regular browser, and those are frequently
    # not subject to the same check. This needs no cookies, no browser, no
    # setup at all — if the plain attempt gets blocked, automatically retry
    # as each of these before giving up. Cast a wide net since it costs
    # nothing extra when the first ones fail fast.
    attempts = [("default", {})] + [
        (client, {"extractor_args": {"youtube": {"player_client": [client]}}})
        for client in (
            "android", "ios", "tv_embedded", "web_embedded", "mweb",
            "web_creator", "android_music", "android_creator", "web_safari",
        )
    ]

    info = None
    last_error = None
    for attempt_index, (label, extra_opts) in enumerate(attempts):
        opts = base_opts()
        opts.update(extra_opts)
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
            break
        except yt_dlp.utils.DownloadError as e:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled("Cancelled by user.")
            last_error = e
            if not is_bot_check_error(e):
                raise ClipperError(str(e))
            if attempt_index < len(attempts) - 1 and progress_cb:
                progress_cb(f"YouTube blocked that attempt — trying another method automatically…")

    if info is None:
        raise ClipperError(str(last_error))

    duration = float(info.get("duration") or 0)
    filepath = ydl.prepare_filename(info)
    # merge_output_format may change extension to mp4
    if not filepath.endswith(".mp4"):
        candidate = os.path.splitext(filepath)[0] + ".mp4"
        if os.path.exists(candidate):
            filepath = candidate

    if not os.path.exists(filepath):
        raise ClipperError("Download finished but the output file is missing.")

    if duration > MAX_SOURCE_DURATION_SEC:
        raise ClipperError(
            f"Video is {duration/60:.1f} min long, which is over the "
            f"{MAX_SOURCE_DURATION_SEC/60:.0f} min limit set in MAX_SOURCE_DURATION_SEC."
        )

    return filepath, duration


LOCAL_VIDEO_EXTENSIONS = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v", ".ts", ".flv", ".wmv"}


def looks_like_local_video_path(text: str) -> bool:
    """True if text looks like a path to an existing local video file (not a URL)."""
    candidate = text.strip().strip('"').strip("'")
    if not candidate or candidate.lower().startswith(("http://", "https://")):
        return False
    ext = os.path.splitext(candidate)[1].lower()
    return ext in LOCAL_VIDEO_EXTENSIONS and os.path.isfile(candidate)


def load_local_video(path: str) -> tuple[str, float]:
    """
    Use an already-local video file directly — e.g. something you already
    downloaded outside the bot — instead of fetching one with yt-dlp. Since
    the bot runs on your own machine, this completely sidesteps Telegram's
    upload limits (bots can only receive files up to ~20MB via the normal
    Bot API): you just tell the bot a path on disk, nothing has to travel
    through Telegram's servers to get in. The original file is only ever
    read from, never copied or modified, so cleanup later can't touch it.
    """
    path = path.strip().strip('"').strip("'")
    if not os.path.isfile(path):
        raise ClipperError(f"File not found: {path}")

    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True,
    )
    try:
        duration = float(result.stdout.strip())
    except (ValueError, AttributeError):
        duration = 0.0

    if duration <= 0:
        raise ClipperError("Couldn't read that as a video file (ffprobe found no duration).")

    if duration > MAX_SOURCE_DURATION_SEC:
        raise ClipperError(
            f"Video is {duration/60:.1f} min long, which is over the "
            f"{MAX_SOURCE_DURATION_SEC/60:.0f} min limit set in MAX_SOURCE_DURATION_SEC."
        )

    return os.path.abspath(path), duration


def _extract_json(text: str) -> list:
    """Gemini sometimes wraps JSON in ```json fences or adds commentary; strip that."""
    text = text.strip()
    fence_match = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1)
    else:
        bracket_match = re.search(r"(\[.*\])", text, re.DOTALL)
        if bracket_match:
            text = bracket_match.group(1)
    return json.loads(text)


def _downscale_for_gemini(source_path: str, job_id: str) -> str:
    """
    Make a smaller/lower-res copy just for uploading to Gemini. This doesn't
    speed up Gemini's own server-side indexing (that scales with duration,
    not resolution), but it noticeably cuts the upload time for big files.
    """
    out_dir = _job_dir(job_id)
    out_path = os.path.join(out_dir, "gemini_preview.mp4")

    cmd = [
        "ffmpeg", "-y",
        "-i", source_path,
        "-vf", "scale=-2:480",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "30",
        "-c:a", "aac", "-b:a", "96k",
        out_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 or not os.path.exists(out_path):
        # If downscaling fails for any reason, just fall back to the original file.
        return source_path
    return out_path


def analyze_video(filepath: str, duration: float, progress_cb=None, cancel_event=None, exclude_ranges=None) -> list[Clip]:
    """Upload the video to Gemini and ask it to pick the best vertical-clip moments."""
    api_key = os.environ.get("GEMINI_API_KEY")  # read fresh, not a module-load-time cache
    if not api_key:
        raise ClipperError("GEMINI_API_KEY is not set.")
    client = genai.Client(api_key=api_key)

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    notify("Uploading to Gemini…")
    try:
        uploaded = client.files.upload(file=filepath)
    except Exception as e:
        raise ClipperError(f"Gemini upload failed: {e}")

    try:
        # Wait for Gemini to finish indexing the file. This step runs at
        # roughly real-time speed relative to the video's length — a 20 min
        # video takes roughly 20 min here. There's no way to speed up
        # Gemini's own server-side processing; this is just visibility into it.
        elapsed = 0
        est_total = max(30, int(duration))
        while not uploaded.state or uploaded.state.name != "ACTIVE":
            if uploaded.state and uploaded.state.name == "FAILED":
                raise ClipperError("Gemini failed to process the uploaded video.")
            _check_cancelled(cancel_event)
            time.sleep(10)
            elapsed += 10
            notify(f"Gemini is indexing the video… ({elapsed}s elapsed, usually takes about as long as the video itself — roughly {est_total}s here)")
            uploaded = client.files.get(name=uploaded.name)
        _check_cancelled(cancel_event)

        notify("Indexing done — picking the best moments…")

        exclude_note = ""
        if exclude_ranges:
            ranges_str = ", ".join(f"{s:.0f}-{e:.0f}s" for s, e in exclude_ranges)
            exclude_note = (
                f"\nThese time ranges have ALREADY been used, so pick DIFFERENT, "
                f"NEW moments that don't overlap with any of them: {ranges_str}\n"
            )

        prompt = f"""
You are an expert short-form video editor who finds viral moments for
YouTube Shorts / TikTok / Reels, similar to tools like Opus Clip or Vibblo.

Watch the attached video (total duration ~{duration:.0f} seconds) and pick the
{MAX_CLIPS} best standalone moments to turn into vertical short clips.
{exclude_note}
Rules:
- Each clip must be between {CLIP_MIN_SEC} and {CLIP_MAX_SEC} seconds long.
- Each clip should work as a standalone story: a hook, a payoff, or a strong
  emotional/funny/insightful beat. Prefer clear start/end points (avoid
  cutting mid-sentence).
- Clips should not overlap.
- Sort clips by how likely they are to perform well, best first.

Return ONLY a JSON array (no markdown, no commentary) in this exact shape:
[
  {{
    "start": <start time in seconds, number>,
    "end": <end time in seconds, number>,
    "title": "<short punchy title for the clip>",
    "reason": "<one sentence on why this moment works>",
    "score": <virality score from 1-10>
  }}
]
"""
        response = client.models.generate_content(model=GEMINI_MODEL, contents=[uploaded, prompt])
        raw_clips = _extract_json(response.text)
    finally:
        try:
            client.files.delete(name=uploaded.name)
        except Exception:
            pass

    clips = []
    for c in raw_clips:
        try:
            start = float(c["start"])
            end = float(c["end"])
        except (KeyError, TypeError, ValueError):
            continue
        if end <= start:
            continue
        start = max(0.0, start)
        end = min(duration, end)
        clips.append(
            Clip(
                start=start,
                end=end,
                title=str(c.get("title", "Clip"))[:100],
                reason=str(c.get("reason", ""))[:300],
                score=float(c.get("score", 0)),
            )
        )

    if not clips:
        raise ClipperError("Gemini didn't return any usable clips for this video.")

    return clips[:MAX_CLIPS]


def _wrap_title(text: str, max_width_px: int, font_size: int = TITLE_FONT_SIZE, max_lines: int = 2) -> list[str]:
    """Wrap title text into at most max_lines lines that fit max_width_px, using the bundled title font."""
    try:
        font = ImageFont.truetype(TITLE_FONT, font_size)
    except Exception:
        font = ImageFont.load_default()

    def text_width(s: str) -> int:
        bbox = font.getbbox(s)
        return bbox[2] - bbox[0]

    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = f"{current} {word}".strip()
        if text_width(trial) <= max_width_px or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)

    if len(lines) > max_lines:
        lines = lines[:max_lines]
        while lines[-1] and text_width(lines[-1] + "…") > max_width_px:
            lines[-1] = lines[-1][:-1]
        lines[-1] = lines[-1].rstrip() + "…"

    return lines


def _render_text_png(text: str, canvas_width: int, dark_text: bool, font_size: int, max_lines: int) -> tuple[str, int] | None:
    """Shared renderer behind render_title_image and render_subtitle_image — see render_title_image for why this is a PNG, not ffmpeg drawtext."""
    if not text:
        return None

    fill = (0, 0, 0, 255) if dark_text else (255, 255, 255, 255)
    outline = (255, 255, 255, 255) if dark_text else (0, 0, 0, 255)

    lines = _wrap_title(text.upper(), max_width_px=canvas_width - 80, font_size=font_size, max_lines=max_lines)
    font = ImageFont.truetype(TITLE_FONT, font_size)
    line_height = int(font_size * 1.25)
    margin = 16
    img_height = line_height * len(lines) + margin * 2
    outline_w = 3 if font_size < 70 else 4

    img = Image.new("RGBA", (canvas_width, img_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    y = margin
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        line_width = bbox[2] - bbox[0]
        x = (canvas_width - line_width) / 2
        for dx in range(-outline_w, outline_w + 1):
            for dy in range(-outline_w, outline_w + 1):
                if dx or dy:
                    draw.text((x + dx, y + dy), line, font=font, fill=outline)
        draw.text((x, y), line, font=font, fill=fill)
        y += line_height

    out_path = os.path.join(tempfile.gettempdir(), f"clipbot_textimg_{uuid.uuid4().hex[:10]}.png")
    img.save(out_path)
    return out_path, img_height


def render_title_image(title: str, canvas_width: int = CANVAS_W, dark_text: bool = False) -> tuple[str, int] | None:
    """
    Render the (wrapped, centered, outlined) title onto a transparent PNG
    using Pillow, instead of ffmpeg's drawtext filter. drawtext embeds the
    font path and/or the text itself directly into the filter-graph string,
    and that string turned out to have multiple different sharp edges
    depending on the exact path/text/ffmpeg-build combination (a folder
    with a space+parenthesis broke it one way, a plain Windows temp path
    broke a different way) — each one very hard to fully predict or
    reproduce ahead of time. Rendering the title as an image sidesteps the
    entire problem: the image is passed to ffmpeg as a normal -i input
    argument, which has none of the filter-graph's escaping rules at all,
    so no path or text content ever needs escaping in the first place.

    The image is a tight fit around the text (small margin only) rather
    than baking in a fixed top offset, so the caller can position it
    (e.g. vertically centered in a blurred padding strip) via the overlay
    filter's y-offset without needing to re-render for different formats.

    dark_text=True swaps to black fill / white outline, for use against a
    white background (white-on-white would otherwise leave only the
    outline visible).

    Returns (png_path, image_height), or None if there's no title to render.
    """
    return _render_text_png(title, canvas_width, dark_text, TITLE_FONT_SIZE, max_lines=3)


def render_subtitle_image(text: str, canvas_width: int = CANVAS_W) -> tuple[str, int] | None:
    """
    Same PNG-based approach as render_title_image, but smaller and capped
    at 2 lines — subtitles are short spoken phrases shown briefly, not a
    persistent headline. Always light text + black outline, since these
    sit directly on top of unpredictable video content.
    """
    return _render_text_png(text, canvas_width, dark_text=False, font_size=SUBTITLE_FONT_SIZE, max_lines=2)


def _cover_scale(w: int, h: int) -> str:
    """ffmpeg filter snippet: scale+crop input to exactly fill a w x h box (center-crop, no distortion)."""
    return f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}"


def _background_branch(style: str, source_label: str, out_label: str, w: int, h: int, duration: float) -> str:
    """
    Build the filter-graph branch that produces the padding background
    behind the foreground video, for whichever BG_STYLE is configured:
      - "blur" (default): the video itself, cropped to cover, blurred.
      - "darkblur": same, additionally darkened for stronger text contrast.
      - "black" / "white": a plain solid color, not derived from the video
        at all (so this ignores source_label and doesn't need the split
        the blur styles need).
    `source_label` is the filter-graph label already holding a copy of the
    input video (e.g. "[bg]" from an earlier split) — only used for the
    blur/darkblur styles.
    """
    if style == "black":
        return f"color=c=black:s={w}x{h}:d={duration:.2f}{out_label}"
    if style == "white":
        return f"color=c=white:s={w}x{h}:d={duration:.2f}{out_label}"
    if style == "darkblur":
        return f"{source_label}{_cover_scale(w, h)},gblur=sigma=20,eq=brightness=-0.35{out_label}"
    return f"{source_label}{_cover_scale(w, h)},gblur=sigma=20{out_label}"  # "blur" (default)


def _get_video_resolution(source_path: str) -> tuple[int, int]:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=s=x:p=0", source_path],
        capture_output=True, text=True,
    )
    try:
        w, h = result.stdout.strip().split("x")
        return int(w), int(h)
    except Exception:
        return 1920, 1080


_LETTERBOX_CACHE: dict[str, tuple[int, int, int, int] | None] = {}


def _detect_letterbox_crop(source_path: str) -> tuple[int, int, int, int] | None:
    """
    Detect solid black letterbox/pillarbox bars baked into the source
    video itself (some reaction/gameplay re-uploads already have these),
    so they can be cropped out before our own blur-padding is applied.
    Otherwise our padding ends up wrapped around an already-bordered
    image, and the source's own bars stay plain black no matter what
    BG_STYLE is set to — blurring solid black just looks like solid black,
    there's no real image data there to blur.

    Returns (w, h, x, y) to crop to, or None if no real border was found
    (cropdetect reporting the full original frame size back means there's
    nothing to crop). Cached per source_path since this only needs to run
    once per video, not once per clip.
    """
    if source_path in _LETTERBOX_CACHE:
        return _LETTERBOX_CACHE[source_path]

    cmd = [
        "ffmpeg", "-i", source_path,
        "-t", "5", "-vf", "cropdetect=24:2:0", "-f", "null", "-",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)

    # Read the source's own resolution from THIS SAME ffmpeg run's log,
    # rather than a separate ffprobe call — if ffprobe and this ffmpeg
    # invocation ever disagreed or one failed to parse a given file
    # (different tools, different parsing), comparing cropdetect's result
    # against a mismatched "full size" could produce a false-positive crop.
    res_match = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})", result.stderr)
    full_w, full_h = (int(res_match.group(1)), int(res_match.group(2))) if res_match else (None, None)

    matches = re.findall(r"crop=(\d+):(\d+):(\d+):(\d+)", result.stderr)

    crop_box = None
    if matches and full_w and full_h:
        w, h, x, y = (int(v) for v in matches[-1])
        # Only worth cropping if it actually trims a meaningful amount —
        # a few pixels of difference isn't a real letterbox, just noise.
        if w > 0 and h > 0 and (full_w - w > 8 or full_h - h > 8):
            crop_box = (w, h, x, y)

    _LETTERBOX_CACHE[source_path] = crop_box
    return crop_box


def detect_facecam_box(source_path: str, duration: float) -> tuple[float, float, float, float] | None:
    """
    Ask Gemini to find a small facecam/webcam inset overlaid on top of the
    main footage (a common layout in gaming/reaction videos), by looking at
    one sample frame. Returns a relative (x0, y0, x1, y1) box in 0-1
    coordinates, or None if no facecam is found (or Gemini isn't configured).
    This is best-effort — if detection fails or looks wrong, callers should
    fall back to the plain TikTok format.
    """
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None

    frame_path = os.path.join(os.path.dirname(source_path), "facecam_probe.jpg")
    sample_t = max(0.5, min(duration * 0.4, duration - 0.5)) if duration > 1 else 0
    cmd = ["ffmpeg", "-y", "-ss", f"{sample_t:.2f}", "-i", source_path, "-vframes", "1", frame_path, "-loglevel", "error"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 or not os.path.exists(frame_path):
        return None

    try:
        client = genai.Client(api_key=api_key)
        uploaded = client.files.upload(file=frame_path)
        prompt = (
            "This is a frame from a gaming or reaction video. Look for a small "
            "rectangular webcam/facecam inset showing a person's face, overlaid on "
            "top of the main footage (NOT the main footage itself). "
            "If you find one, return ONLY JSON: "
            '{"found": true, "x0": <0-1>, "y0": <0-1>, "x1": <0-1>, "y1": <0-1>} '
            "(relative to the full frame). If there is no such inset, return "
            '{"found": false}. No markdown, no commentary.'
        )
        response = client.models.generate_content(model=GEMINI_MODEL, contents=[uploaded, prompt])
        try:
            client.files.delete(name=uploaded.name)
        except Exception:
            pass

        data = json.loads(re.search(r"\{.*\}", response.text, re.DOTALL).group(0))
        if not data.get("found"):
            return None
        box = (float(data["x0"]), float(data["y0"]), float(data["x1"]), float(data["y1"]))
        if box[2] <= box[0] or box[3] <= box[1]:
            return None
        return box
    except Exception:
        return None
    finally:
        if os.path.exists(frame_path):
            os.remove(frame_path)


def cut_clip(source_path: str, clip: Clip, job_id: str, index: int, fmt: str = "tiktok", facecam_box=None) -> str:
    """
    Cut [clip.start, clip.end] from source_path into a 1080x1920 vertical
    clip, with a burned-in title, in one of four formats:
      - "tiktok" (default): full frame preserved, padding above/below.
      - "square": center 1:1 crop, same padding above/below.
      - "aspect43": center 4:3 crop, same padding above/below.
      - "facecam": requires facecam_box (relative x0,y0,x1,y1) — stacks the
        detected facecam region on top and the main footage below (no
        padding zone, so BG_STYLE doesn't apply to this one).

    The padding style (BG_STYLE: "blur" / "darkblur" / "black" / "white")
    applies to the first three. The title, when present, is vertically
    centered within that padding zone (computed per-format, since a
    landscape source video's padding is a different height than a square
    crop's), not just pinned near the top.
    """
    out_dir = _job_dir(job_id)
    out_path = os.path.join(out_dir, f"clip_{index}_{uuid.uuid4().hex[:6]}.mp4")
    duration = clip.end - clip.start
    # Facecam titles sit directly on top of gameplay footage, not a solid
    # BG_STYLE-colored strip, so they always use light text + outline for
    # readability against whatever's playing — BG_STYLE's dark-text swap
    # only makes sense for the other formats' solid/blurred padding zones.
    dark_text = (BG_STYLE == "white") and fmt != "facecam"
    title_render = render_title_image(clip.title, dark_text=dark_text)

    # Detect (once per source, cached) any solid black bars already baked
    # into the source footage itself, and crop them out before any of our
    # own scaling/padding math runs — otherwise our own blur-padding wraps
    # around an already-bordered image, and the source's own bars stay
    # plain black regardless of BG_STYLE (there's no real image there to blur).
    letterbox = _detect_letterbox_crop(source_path)
    if letterbox:
        lb_w, lb_h, lb_x, lb_y = letterbox
        pre_filter = f"[0:v]crop={lb_w}:{lb_h}:{lb_x}:{lb_y}[srcv];"
        SRC = "[srcv]"
        eff_resolution = (lb_w, lb_h)
    else:
        pre_filter = ""
        SRC = "[0:v]"
        eff_resolution = None

    def source_resolution() -> tuple[int, int]:
        return eff_resolution if eff_resolution else _get_video_resolution(source_path)

    facecam_cam_zone_h = None  # set below only for fmt == "facecam"; used to position the title strip
    def letterboxed_filter(fg_filter_expr: str, fg_h: int) -> tuple[str, int]:
        """Composite a cropped/scaled foreground over a full-canvas background,
        using whichever BG_STYLE is configured. Returns (filter_str, top_padding_height)."""
        top_pad_h = max(0, (CANVAS_H - fg_h) // 2)
        if BG_STYLE in ("black", "white"):
            filt = (
                f"{SRC}{fg_filter_expr}[fg];"
                f"{_background_branch(BG_STYLE, '', '[bgfinal]', CANVAS_W, CANVAS_H, duration)};"
                f"[bgfinal][fg]overlay=(W-w)/2:(H-h)/2[vbase]"
            )
        else:
            filt = (
                f"{SRC}split=2[bgsrc][fgsrc];"
                f"{_background_branch(BG_STYLE, '[bgsrc]', '[bgfinal]', CANVAS_W, CANVAS_H, duration)};"
                f"[fgsrc]{fg_filter_expr}[fg];"
                f"[bgfinal][fg]overlay=(W-w)/2:(H-h)/2[vbase]"
            )
        return filt, top_pad_h

    if fmt == "square":
        filter_complex, top_pad_h = letterboxed_filter(
            f"crop='min(iw\\,ih)':'min(iw\\,ih)',scale={CANVAS_W}:{CANVAS_W}", CANVAS_W
        )
    elif fmt == "aspect43":
        fg_h = int(CANVAS_W * 3 / 4)  # 1080 * 3/4 = 810
        filter_complex, top_pad_h = letterboxed_filter(
            f"crop='min(iw\\,ih*4/3)':'min(ih\\,iw*3/4)',scale={CANVAS_W}:{fg_h}", fg_h
        )
    elif fmt == "facecam" and facecam_box:
        src_w, src_h = source_resolution()
        x0, y0, x1, y1 = facecam_box
        cam_x, cam_y = int(x0 * src_w), int(y0 * src_h)
        cam_w, cam_h = max(2, int((x1 - x0) * src_w)), max(2, int((y1 - y0) * src_h))

        # No separate title strip — camera and gameplay each fill their full
        # zone edge-to-edge (cover-cropped, no blur), and the title is
        # burned directly on top of the gameplay footage near the top of
        # that zone, instead of taking up its own dedicated space.
        cam_zone_h = FACECAM_ZONE_H
        gameplay_zone_h = CANVAS_H - cam_zone_h

        cam_chain = f"{SRC}split=2[camsrc][mainsrc];[camsrc]crop={cam_w}:{cam_h}:{cam_x}:{cam_y},{_cover_scale(CANVAS_W, cam_zone_h)}[camout];"
        main_chain = f"[mainsrc]{_cover_scale(CANVAS_W, gameplay_zone_h)}[mainout];"
        filter_complex = (
            f"{cam_chain}{main_chain}"
            f"[camout][mainout]vstack=inputs=2[vbase]"
        )
        top_pad_h = 0
        facecam_cam_zone_h = cam_zone_h
    else:  # "tiktok" — full frame preserved, padding above/below
        src_w, src_h = source_resolution()
        fg_h = min(CANVAS_H, round(CANVAS_W * src_h / src_w))
        filter_complex, top_pad_h = letterboxed_filter(
            f"scale={CANVAS_W}:-2:force_original_aspect_ratio=decrease", fg_h
        )

    filter_complex = pre_filter + filter_complex

    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{clip.start:.2f}",
        "-t", f"{duration:.2f}",
        "-i", source_path,
    ]

    current = "[vbase]"
    stage = 0
    input_count = 1  # source_path is already input 0
    overlay_image_paths = []

    def _next_label():
        nonlocal stage
        stage += 1
        return f"[stage{stage}]"

    if title_render:
        title_image_path, title_img_h = title_render
        overlay_image_paths.append(title_image_path)
        if facecam_cam_zone_h is not None:
            # Facecam mode: no separate title strip — burn the title
            # directly on top of the gameplay footage, positioned just
            # below the camera/gameplay seam so it reads clearly over the
            # top of the gameplay zone.
            title_y = facecam_cam_zone_h + 30
        else:
            # Vertically center the title within the padding zone normally.
            # As the title gets taller (more lines), this smoothly slides it
            # up toward the very top of the frame instead — clamped so it can
            # never spill down past the padding zone into the actual video,
            # no matter how long the title or how few lines it fits in.
            title_y = max(0, (top_pad_h - title_img_h) // 2)
        # The title image is a completely separate input (like the video),
        # not text embedded in the filter graph — see render_title_image
        # for why. -loop 1 makes the single-frame PNG act as a continuous
        # source so it stays composited for the whole clip.
        cmd += ["-loop", "1", "-t", f"{duration:.2f}", "-i", title_image_path]
        title_input_idx = input_count
        input_count += 1
        out_label = _next_label()
        filter_complex += f";{current}[{title_input_idx}:v]overlay=0:{title_y}{out_label}"
        current = out_label

    if SUBTITLES_ENABLED:
        # Vertical center of the "gameplay" zone — for facecam, that's the
        # lower zone below the camera; every other format has no separate
        # zone, so it's just the center of the whole frame.
        if facecam_cam_zone_h is not None:
            zone_top, zone_h = facecam_cam_zone_h, CANVAS_H - facecam_cam_zone_h
        else:
            zone_top, zone_h = 0, CANVAS_H
        for seg_start, seg_end, text in _transcribe_clip_audio(source_path, clip.start, clip.end):
            seg_start = max(0.0, min(seg_start, duration))
            seg_end = max(seg_start, min(seg_end, duration))
            if seg_end <= seg_start:
                continue
            render = render_subtitle_image(text)
            if not render:
                continue
            sub_path, sub_h = render
            overlay_image_paths.append(sub_path)
            sub_y = zone_top + max(0, (zone_h - sub_h) // 2)
            # Same trick as the title: looped for the full clip so it's a
            # normal continuous input, but only actually shown during its
            # own [seg_start, seg_end] window via overlay's enable option.
            cmd += ["-loop", "1", "-t", f"{duration:.2f}", "-i", sub_path]
            sub_input_idx = input_count
            input_count += 1
            out_label = _next_label()
            filter_complex += (
                f";{current}[{sub_input_idx}:v]overlay=0:{sub_y}:"
                f"enable='between(t,{seg_start:.2f},{seg_end:.2f})'{out_label}"
            )
            current = out_label

    filter_complex += f";{current}null[vout]"

    cmd += [
        "-filter_complex", filter_complex,
        "-map", "[vout]", "-map", "0:a?",
        "-shortest",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "128k",
        out_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
    finally:
        for p in overlay_image_paths:
            try:
                os.remove(p)
            except OSError:
                pass

    if result.returncode != 0 or not os.path.exists(out_path):
        if fmt == "facecam":
            # Facecam layout failed (e.g. bad box) — fall back to plain tiktok format.
            return cut_clip(source_path, clip, job_id, index, fmt="tiktok")
        raise ClipperError(f"ffmpeg failed on clip {index}: {result.stderr[-500:]}")

    return out_path


# Kept for backwards compatibility with any direct callers.
def cut_clip_vertical(source_path: str, clip: Clip, job_id: str, index: int) -> str:
    return cut_clip(source_path, clip, job_id, index, fmt="tiktok")


def _enforce_min_length(start: float, end: float, duration: float, min_len: int = CLIP_MIN_SEC) -> tuple[float, float]:
    """
    Make sure a clip is at least min_len seconds, by extending it forward
    (and then backward if there isn't enough room ahead), clamped to the
    source video's actual duration.
    """
    length = end - start
    if length >= min_len or duration <= 0:
        return start, end

    deficit = min_len - length
    new_end = min(duration, end + deficit)
    deficit -= new_end - end
    end = new_end
    if deficit > 0:
        start = max(0.0, start - deficit)
    return start, end


def parse_timestamps(text: str) -> list[tuple[float, float]] | None:
    """
    Parse manual timestamp ranges out of free text, e.g.:
      "0:10-0:45, 1:20-2:00"
      "10-45\n80-120"
      "1:02:00-1:03:30"
    Returns a list of (start_sec, end_sec) or None if nothing valid was found.
    """

    def to_seconds(token: str) -> float:
        parts = token.strip().split(":")
        parts = [float(p) for p in parts]
        while len(parts) < 3:
            parts.insert(0, 0.0)
        h, m, s = parts[-3], parts[-2], parts[-1]
        return h * 3600 + m * 60 + s

    pattern = re.compile(r"(\d{1,2}(?::\d{1,2}){0,2})\s*-\s*(\d{1,2}(?::\d{1,2}){0,2})")
    matches = pattern.findall(text)
    if not matches:
        return None

    ranges = []
    for start_str, end_str in matches:
        try:
            start = to_seconds(start_str)
            end = to_seconds(end_str)
        except ValueError:
            continue
        if end > start:
            ranges.append((start, end))

    return ranges or None


def build_manual_clips(ranges: list[tuple[float, float]], duration: float) -> list[Clip]:
    """Turn raw (start, end) ranges into Clip objects, exactly as given — manual timestamps are the
    user's explicit choice, so unlike auto-picked clips they're never stretched to a minimum length."""
    clips = []
    for i, (start, end) in enumerate(ranges, start=1):
        start = max(0.0, start)
        end = min(duration, end)
        if end <= start:
            continue
        clips.append(Clip(start=start, end=end, title="", reason="Manually selected timestamp", score=0.0))
    return clips


def generate_quick_title(source_path: str, start: float, end: float, job_id: str) -> str:
    """
    Grab a single frame from the middle of [start, end] and ask Gemini for a
    short punchy title. Used for manual/timestamp clips, which (unlike
    auto-mode ones) don't already have an AI-suggested title from a full
    video analysis. Falls back to a generic title if Gemini isn't available
    or fails for any reason — this is a nice-to-have, not worth failing over.
    """
    api_key = os.environ.get("GEMINI_API_KEY")
    fallback = "Clip"
    if not api_key:
        return fallback

    frame_path = os.path.join(_job_dir(job_id), f"title_probe_{uuid.uuid4().hex[:6]}.jpg")
    mid_t = max(0.0, min((start + end) / 2, end - 0.1))
    cmd = ["ffmpeg", "-y", "-ss", f"{mid_t:.2f}", "-i", source_path, "-vframes", "1", frame_path, "-loglevel", "error"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 or not os.path.exists(frame_path):
        return fallback

    try:
        client = genai.Client(api_key=api_key)
        uploaded = client.files.upload(file=frame_path)
        prompt = (
            "Give this video frame a SHORT, punchy 2-5 word title suitable for a "
            "short-form video clip. No emojis, no quotes, no trailing punctuation. "
            "Only the title, nothing else."
        )
        response = client.models.generate_content(model=GEMINI_MODEL, contents=[uploaded, prompt])
        try:
            client.files.delete(name=uploaded.name)
        except Exception:
            pass
        title = response.text.strip().strip('"\'').rstrip(".!?")
        return title[:60] if title else fallback
    except Exception:
        return fallback
    finally:
        if os.path.exists(frame_path):
            os.remove(frame_path)


def cut_ranges(
    source_path: str,
    ranges: list[tuple[float, float]],
    duration: float,
    job_id: str,
    progress_cb=None,
    cancel_event=None,
    fmt: str = "tiktok",
) -> list[tuple[str, Clip]]:
    """Cut exactly the given (start, end) ranges from an already-downloaded video."""

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    facecam_box = None
    if fmt == "facecam":
        notify("Looking for a facecam in the video…")
        facecam_box = detect_facecam_box(source_path, duration)
        if not facecam_box:
            notify("No facecam detected — using the standard TikTok format instead.")
            fmt = "tiktok"

    results = []
    for i, (start, end) in enumerate(ranges, start=1):
        _check_cancelled(cancel_event)
        start = max(0.0, start)
        end = min(duration, end)
        if end <= start:
            continue
        clip = Clip(
            start=start,
            end=end,
            title=f"Manual clip {i}",
            reason="Manually selected timestamp",
            score=0.0,
        )
        notify(f"Cutting clip {i}/{len(ranges)}: {start:.0f}s–{end:.0f}s")
        clip_path = cut_clip(source_path, clip, job_id, i, fmt=fmt, facecam_box=facecam_box)
        results.append((clip_path, clip))

    if not results:
        raise ClipperError("None of the given timestamp ranges fit inside the video's duration.")

    return results


def process_manual_timestamps(
    url: str,
    ranges: list[tuple[float, float]],
    job_id: str | None = None,
    progress_cb=None,
    cancel_event=None,
    fmt: str = "tiktok",
) -> list[tuple[str, Clip]]:
    """Download the video, then cut exactly the timestamp ranges given (no AI, no quota used)."""
    job_id = job_id or uuid.uuid4().hex[:10]

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    notify("Downloading video…")
    source_path, duration = download_video(url, job_id, cancel_event=cancel_event)
    return cut_ranges(source_path, ranges, duration, job_id, progress_cb, cancel_event=cancel_event, fmt=fmt)


def get_auto_clips(source_path: str, duration: float, job_id: str, progress_cb=None, cancel_event=None, exclude_ranges=None) -> list[Clip]:
    """Ask Gemini to pick the best moments, without cutting anything yet."""

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    _check_cancelled(cancel_event)
    notify("Preparing a smaller copy for Gemini…")
    upload_path = _downscale_for_gemini(source_path, job_id)
    clips = analyze_video(upload_path, duration, progress_cb, cancel_event=cancel_event, exclude_ranges=exclude_ranges)
    for clip in clips:
        clip.start, clip.end = _enforce_min_length(clip.start, clip.end, duration)
    return clips


def resolve_format(source_path: str, duration: float, fmt: str, progress_cb=None) -> tuple[str, tuple | None]:
    """
    For "facecam", runs detection once and falls back to "tiktok" if nothing
    is found. Returns (actual_fmt_to_use, facecam_box_or_None). For any other
    format, just returns (fmt, None) unchanged.
    """

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    if fmt != "facecam":
        return fmt, None

    notify("Looking for a facecam in the video…")
    facecam_box = detect_facecam_box(source_path, duration)
    if not facecam_box:
        notify("No facecam detected — using the standard landscape format instead.")
        return "tiktok", None
    return fmt, facecam_box


def analyze_and_cut(
    source_path: str,
    duration: float,
    job_id: str,
    progress_cb=None,
    cancel_event=None,
    fmt: str = "tiktok",
) -> list[tuple[str, Clip]]:
    """Ask Gemini to pick the best moments in an already-downloaded video, then cut them."""

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    clips = get_auto_clips(source_path, duration, job_id, progress_cb, cancel_event)
    fmt, facecam_box = resolve_format(source_path, duration, fmt, progress_cb)

    results = []
    for i, clip in enumerate(clips, start=1):
        _check_cancelled(cancel_event)
        notify(f"Cutting clip {i}/{len(clips)}: {clip.title}")
        clip_path = cut_clip(source_path, clip, job_id, i, fmt=fmt, facecam_box=facecam_box)
        results.append((clip_path, clip))

    return results


def process_youtube_url(
    url: str, job_id: str | None = None, progress_cb=None, cancel_event=None, fmt: str = "tiktok"
) -> list[tuple[str, Clip]]:
    """
    Full pipeline: download -> analyze -> cut.
    progress_cb(str) is called with status updates if provided.
    Returns a list of (clip_filepath, Clip) tuples.
    """
    job_id = job_id or uuid.uuid4().hex[:10]

    def notify(msg):
        if progress_cb:
            progress_cb(msg)

    notify("Downloading video…")
    source_path, duration = download_video(url, job_id, cancel_event=cancel_event)
    return analyze_and_cut(source_path, duration, job_id, progress_cb, cancel_event=cancel_event, fmt=fmt)
