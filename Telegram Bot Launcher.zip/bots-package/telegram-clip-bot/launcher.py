"""
launcher.py
-----------
One desktop window to run either of your bots:
  - Clip & Caption Bot   (this folder — auto/manual YouTube/TikTok clipper)
  - Video Rater Bot      (your separate ranking/countdown-merge bot)

Enter the API keys for whichever bot you pick, press Start, and it saves
the keys into that bot's own .env file and launches it — with a live log
and a Stop button.

Each bot gets its own isolated virtual environment (a ".venv" folder
created inside that bot's own folder) so installing one bot's dependencies
can never downgrade or break the other's — they used to share your global
Python environment, which caused real conflicts (e.g. one bot's older
httpx requirement silently breaking the other bot's newer library).

Run it with:
    python launcher.py
"""

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LAUNCHER_CONFIG_PATH = os.path.join(BASE_DIR, "launcher_config.json")

# Each bot: display name -> (env var name for the telegram token, default folder)
# "Clip & Caption Bot" defaults to the folder launcher.py itself lives in.
BOTS = {
    "Clip & Caption Bot": {
        "telegram_env": "TELEGRAM_BOT_TOKEN",
        "gemini_env": "GEMINI_API_KEY",
        "default_dir": BASE_DIR,
        "extra": "format",
    },
    "Video Rater Bot": {
        "telegram_env": "TELEGRAM_TOKEN",
        "gemini_env": "GEMINI_API_KEY",
        "default_dir": "",
        "extra": "blur",
    },
}

# Clip & Caption Bot's output format — set once per session here instead of
# per-video in Telegram. display label -> CLIP_FORMAT value
FORMAT_OPTIONS = {
    "Fullscreen (9:16) — full landscape video, rest padded": "tiktok",
    "4:3 Aspect — centered crop, rest padded": "aspect43",
    "Square (1:1) — centered crop, rest padded": "square",
    "Facecam Gameplay — cam on top, gameplay below": "facecam",
}
FORMAT_VALUE_TO_LABEL = {v: k for k, v in FORMAT_OPTIONS.items()}

# The padding style behind the video/crop for the tiktok/aspect43/square
# formats (facecam has no padding zone, so this doesn't apply to it).
BG_OPTIONS = {
    "Blur (default)": "blur",
    "Dark Blur": "darkblur",
    "Solid Black": "black",
    "Solid White": "white",
}
BG_VALUE_TO_LABEL = {v: k for k, v in BG_OPTIONS.items()}


def read_env(env_path: str) -> dict:
    values = {}
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                values[key.strip()] = val.strip()
    return values


def write_env(env_path: str, updates: dict):
    """Update a .env file in place, preserving any other keys already in it."""
    lines = []
    seen = set()

    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for raw_line in f:
                stripped = raw_line.strip()
                if stripped and not stripped.startswith("#") and "=" in stripped:
                    key = stripped.split("=", 1)[0].strip()
                    if key in updates:
                        lines.append(f"{key}={updates[key]}\n")
                        seen.add(key)
                        continue
                lines.append(raw_line if raw_line.endswith("\n") else raw_line + "\n")

    for key, val in updates.items():
        if key not in seen:
            lines.append(f"{key}={val}\n")

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(lines)


def load_launcher_config() -> dict:
    if os.path.exists(LAUNCHER_CONFIG_PATH):
        try:
            with open(LAUNCHER_CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_launcher_config(config: dict):
    try:
        with open(LAUNCHER_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass


def venv_dir(folder: str) -> str:
    return os.path.join(folder, ".venv")


def venv_python(folder: str) -> str:
    if os.name == "nt":
        return os.path.join(venv_dir(folder), "Scripts", "python.exe")
    return os.path.join(venv_dir(folder), "bin", "python")


def venv_exists(folder: str) -> bool:
    return os.path.exists(venv_python(folder))


class ToolTip:
    """A small popup that appears on hover, showing a hint like where to get an API key."""

    def __init__(self, widget, text: str):
        self.widget = widget
        self.text = text
        self.tip_window = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, event=None):
        if self.tip_window or not self.text:
            return
        x = self.widget.winfo_rootx() + 18
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(
            tw, text=self.text, justify="left", background="#ffffe0", foreground="#000000",
            relief="solid", borderwidth=1, font=("TkDefaultFont", 9), wraplength=320,
        ).pack(ipadx=5, ipady=3)

    def _hide(self, event=None):
        if self.tip_window:
            self.tip_window.destroy()
            self.tip_window = None


class LauncherApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Bot Launcher - Github/Tryzubq")
        self.root.geometry("660x780")
        self.root.minsize(600, 600)

        self.process: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.config_data = load_launcher_config()

        # In-memory cache of whatever's currently typed for each bot, even if
        # Start was never pressed — so switching the dropdown back and forth
        # never loses a folder/token/key you already typed in this session.
        self.session_cache: dict[str, dict] = {}
        self._current_bot_name: str | None = None

        pad = {"padx": 12, "pady": 6}

        # --- Bot selector ---
        top = ttk.Frame(root)
        top.pack(fill="x", **pad)
        ttk.Label(top, text="Bot:").pack(side="left")
        self.bot_var = tk.StringVar(value=self.config_data.get("last_bot", "Clip & Caption Bot"))
        self.bot_combo = ttk.Combobox(top, textvariable=self.bot_var, values=list(BOTS.keys()), state="readonly", width=30)
        self.bot_combo.pack(side="left", padx=8)
        self.bot_combo.bind("<<ComboboxSelected>>", lambda e: self._on_bot_change())

        # --- Folder picker ---
        folder_frame = ttk.Frame(root)
        folder_frame.pack(fill="x", **pad)
        ttk.Label(folder_frame, text="Bot folder").grid(row=0, column=0, sticky="w")
        self.folder_var = tk.StringVar()
        self.folder_entry = ttk.Entry(folder_frame, textvariable=self.folder_var, width=54)
        self.folder_entry.grid(row=1, column=0, sticky="we")
        ttk.Button(folder_frame, text="Browse…", command=self._browse_folder).grid(row=1, column=1, padx=(6, 0))
        folder_frame.columnconfigure(0, weight=1)

        # --- Key fields ---
        form = ttk.Frame(root)
        form.pack(fill="x", **pad)

        telegram_label_row = ttk.Frame(form)
        telegram_label_row.grid(row=0, column=0, columnspan=2, sticky="w")
        self.telegram_label = ttk.Label(telegram_label_row, text="Telegram Bot Token")
        self.telegram_label.pack(side="left")
        telegram_info = ttk.Label(telegram_label_row, text=" ⓘ", foreground="#5b9bd5", cursor="question_arrow")
        telegram_info.pack(side="left")
        ToolTip(telegram_info, "Get this from @BotFather on Telegram:\nmessage it, send /newbot, and copy the\ntoken it gives you.")

        self.telegram_var = tk.StringVar()
        self.telegram_entry = ttk.Entry(form, textvariable=self.telegram_var, show="•", width=52)
        self.telegram_entry.grid(row=1, column=0, columnspan=2, sticky="we", pady=(0, 10))

        gemini_label_row = ttk.Frame(form)
        gemini_label_row.grid(row=2, column=0, columnspan=2, sticky="w")
        ttk.Label(gemini_label_row, text="Gemini API Key").pack(side="left")
        gemini_info = ttk.Label(gemini_label_row, text=" ⓘ", foreground="#5b9bd5", cursor="question_arrow")
        gemini_info.pack(side="left")
        ToolTip(gemini_info, "Get this from https://aistudio.google.com/apikey\n(free with a Google account).")

        self.gemini_var = tk.StringVar()
        self.gemini_entry = ttk.Entry(form, textvariable=self.gemini_var, show="•", width=52)
        self.gemini_entry.grid(row=3, column=0, columnspan=2, sticky="we", pady=(0, 4))

        self.show_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(form, text="Show keys", variable=self.show_var, command=self._toggle_show).grid(row=4, column=0, sticky="w")

        form.columnconfigure(0, weight=1)
        form.columnconfigure(1, weight=1)

        # --- Per-bot extra option (shown/hidden depending on which bot is selected) ---
        self.format_frame = ttk.Frame(root)
        ttk.Label(self.format_frame, text="Output format").pack(anchor="w")
        self.format_var = tk.StringVar(value=list(FORMAT_OPTIONS.keys())[0])
        self.format_combo = ttk.Combobox(
            self.format_frame, textvariable=self.format_var, values=list(FORMAT_OPTIONS.keys()),
            state="readonly", width=52,
        )
        self.format_combo.pack(fill="x")

        ttk.Label(self.format_frame, text="Background (behind the video/crop)").pack(anchor="w", pady=(8, 0))
        self.bg_var = tk.StringVar(value=list(BG_OPTIONS.keys())[0])
        self.bg_combo = ttk.Combobox(
            self.format_frame, textvariable=self.bg_var, values=list(BG_OPTIONS.keys()),
            state="readonly", width=52,
        )
        self.bg_combo.pack(fill="x")

        self.subtitles_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            self.format_frame,
            text="Burn in auto-generated subtitles (local speech-to-text, no API key needed)",
            variable=self.subtitles_var,
        ).pack(anchor="w", pady=(8, 0))

        cookies_label_row = ttk.Frame(self.format_frame)
        cookies_label_row.pack(anchor="w", pady=(8, 0))
        ttk.Label(cookies_label_row, text="Cookies file (optional)").pack(side="left")
        cookies_info = ttk.Label(cookies_label_row, text=" ⓘ", foreground="#5b9bd5", cursor="question_arrow")
        cookies_info.pack(side="left")
        ToolTip(
            cookies_info,
            "Fixes YouTube's \"sign in to confirm you're not a\n"
            "bot\" / \"page needs to be reloaded\" errors.\n\n"
            "Install the \"Get cookies.txt LOCALLY\" browser\n"
            "extension, open youtube.com while logged in,\n"
            "click the extension and Export, then pick that\n"
            "downloaded file here. See the main README's\n"
            "\"Fixing YouTube download errors\" section for\n"
            "full steps.",
        )
        cookies_row = ttk.Frame(self.format_frame)
        cookies_row.pack(fill="x")
        self.cookies_var = tk.StringVar(value="")
        self.cookies_entry = ttk.Entry(cookies_row, textvariable=self.cookies_var, state="readonly")
        self.cookies_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(cookies_row, text="Browse…", command=self._browse_cookies_file).pack(side="left", padx=(6, 0))
        ttk.Button(cookies_row, text="Clear", command=lambda: self.cookies_var.set("")).pack(side="left", padx=(6, 0))

        self.blur_frame = ttk.Frame(root)
        self.blur_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            self.blur_frame, text="Blur background behind square clips (instead of a black bar)",
            variable=self.blur_var,
        ).pack(anchor="w")

        # --- Buttons ---
        self.btn_frame = ttk.Frame(root)
        self.btn_frame.pack(fill="x", **pad)
        btn_frame = self.btn_frame

        self.install_btn = ttk.Button(btn_frame, text="📦 Install Requirements", command=self.install_requirements)
        self.install_btn.pack(side="left", padx=(0, 8))

        self.start_btn = ttk.Button(btn_frame, text="▶ Start Bot", command=self.start_bot)
        self.start_btn.pack(side="left", padx=(0, 8))

        self.stop_btn = ttk.Button(btn_frame, text="■ Stop Bot", command=self.stop_bot, state="disabled")
        self.stop_btn.pack(side="left")

        self.status_var = tk.StringVar(value="Stopped")
        ttk.Label(btn_frame, textvariable=self.status_var, foreground="gray").pack(side="right")

        ttk.Label(root, text="Log:").pack(anchor="w", padx=12)
        self.log_box = scrolledtext.ScrolledText(root, height=16, state="disabled", bg="#111", fg="#ddd")
        self.log_box.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(150, self._drain_log_queue)

        self._on_bot_change(initial=True)

    # ------------------------------------------------------------------
    def _current_bot_info(self):
        return BOTS[self.bot_var.get()]

    def _snapshot_current_fields(self) -> dict:
        return {
            "folder": self.folder_var.get().strip(),
            "telegram": self.telegram_var.get().strip(),
            "gemini": self.gemini_var.get().strip(),
            "format_label": self.format_var.get(),
            "bg_label": self.bg_var.get(),
            "subtitles": self.subtitles_var.get(),
            "cookies": self.cookies_var.get(),
            "blur": self.blur_var.get(),
        }

    def _show_extra_widget(self, extra: str):
        self.format_frame.pack_forget()
        self.blur_frame.pack_forget()
        pad = {"padx": 12, "pady": 6}
        if extra == "format":
            self.format_frame.pack(fill="x", before=self.btn_frame, **pad)
        elif extra == "blur":
            self.blur_frame.pack(fill="x", before=self.btn_frame, **pad)

    def _on_bot_change(self, initial: bool = False):
        # Cache whatever was in the fields for the bot we're leaving, so
        # nothing typed is lost even if Start/Browse was never pressed —
        # both in memory (for switching within this session) and on disk
        # (so it's still there next time the launcher itself is opened).
        if self._current_bot_name is not None:
            snapshot = self._snapshot_current_fields()
            self.session_cache[self._current_bot_name] = snapshot
            self.config_data.setdefault("bot_settings", {})[self._current_bot_name] = snapshot
            save_launcher_config(self.config_data)

        bot_name = self.bot_var.get()
        info = BOTS[bot_name]
        self._current_bot_name = bot_name

        cached = self.session_cache.get(bot_name) or self.config_data.get("bot_settings", {}).get(bot_name)
        if cached is not None:
            self.folder_var.set(cached["folder"])
            self.telegram_var.set(cached["telegram"])
            self.gemini_var.set(cached["gemini"])
            self.format_var.set(cached.get("format_label", list(FORMAT_OPTIONS.keys())[0]))
            self.bg_var.set(cached.get("bg_label", list(BG_OPTIONS.keys())[0]))
            self.subtitles_var.set(cached.get("subtitles", False))
            self.cookies_var.set(cached.get("cookies", ""))
            self.blur_var.set(cached.get("blur", True))
            self.session_cache[bot_name] = cached
        else:
            saved_folder = self.config_data.get("folders", {}).get(bot_name, info["default_dir"])
            self.folder_var.set(saved_folder)
            self._load_keys_from_folder()
            self.session_cache[bot_name] = self._snapshot_current_fields()

        # (Telegram Bot Token label text stays plain now — no env var name suffix.)
        self._show_extra_widget(info.get("extra"))

        if not initial:
            self.config_data["last_bot"] = bot_name
            save_launcher_config(self.config_data)

    def _load_keys_from_folder(self):
        info = self._current_bot_info()
        folder = self.folder_var.get().strip()
        env_path = os.path.join(folder, ".env") if folder else ""
        existing = read_env(env_path) if env_path else {}
        self.telegram_var.set(existing.get(info["telegram_env"], ""))
        self.gemini_var.set(existing.get(info["gemini_env"], ""))

        if info.get("extra") == "format":
            value = existing.get("CLIP_FORMAT", "tiktok")
            self.format_var.set(FORMAT_VALUE_TO_LABEL.get(value, list(FORMAT_OPTIONS.keys())[0]))
            bg_value = existing.get("BG_STYLE", "blur")
            self.bg_var.set(BG_VALUE_TO_LABEL.get(bg_value, list(BG_OPTIONS.keys())[0]))
            self.subtitles_var.set(existing.get("SUBTITLES_ENABLED", "false").strip().lower() in ("1", "true", "yes", "on"))
            self.cookies_var.set(existing.get("COOKIES_FILE", ""))
        elif info.get("extra") == "blur":
            value = existing.get("BLUR_BACKGROUND", "true")
            self.blur_var.set(value.strip().lower() != "false")

    def _browse_folder(self):
        chosen = filedialog.askdirectory(title="Select the bot's folder (the one containing bot.py)")
        if chosen:
            self.folder_var.set(chosen)
            bot_name = self.bot_var.get()
            self.config_data.setdefault("folders", {})[bot_name] = chosen
            save_launcher_config(self.config_data)
            self._load_keys_from_folder()
            self.session_cache[bot_name] = self._snapshot_current_fields()

    def _browse_cookies_file(self):
        chosen = filedialog.askopenfilename(
            title="Select your cookies.txt file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if chosen:
            self.cookies_var.set(chosen)
            bot_name = self.bot_var.get()
            self.session_cache[bot_name] = self._snapshot_current_fields()

    def _toggle_show(self):
        show_char = "" if self.show_var.get() else "•"
        self.telegram_entry.config(show=show_char)
        self.gemini_entry.config(show=show_char)

    def _append_log(self, text: str):
        self.log_box.config(state="normal")
        self.log_box.insert("end", text)
        self.log_box.see("end")
        self.log_box.config(state="disabled")

    def _set_busy(self, busy: bool):
        state = "disabled" if busy else "normal"
        self.install_btn.config(state=state)
        self.start_btn.config(state=state if self.process is None else "disabled")
        self.bot_combo.config(state="disabled" if busy else "readonly")

    # ------------------------------------------------------------------
    def install_requirements(self):
        if self.process is not None:
            messagebox.showinfo("Bot is running", "Stop the bot first, then install requirements.")
            return

        folder = self.folder_var.get().strip()
        if not folder or not os.path.isdir(folder):
            messagebox.showwarning("Missing folder", "Pick the bot's folder first.")
            return

        req_path = os.path.join(folder, "requirements.txt")
        if not os.path.exists(req_path):
            messagebox.showerror("requirements.txt not found", f"No requirements.txt in:\n{folder}")
            return

        self._set_busy(True)

        def run_install():
            try:
                if not venv_exists(folder):
                    self.log_queue.put(f"\nCreating an isolated environment in {venv_dir(folder)} …\n")
                    result = subprocess.run(
                        [sys.executable, "-m", "venv", venv_dir(folder)],
                        capture_output=True, text=True,
                    )
                    if result.returncode != 0:
                        self.log_queue.put(f"\n❌ Couldn't create the virtual environment:\n{result.stderr[-800:]}\n")
                        self.log_queue.put("__INSTALL_DONE__")
                        return

                py = venv_python(folder)
                self.log_queue.put(f"\nInstalling requirements from {req_path} (into this bot's own environment) …\n")
                proc = subprocess.Popen(
                    [py, "-m", "pip", "install", "-r", "requirements.txt"],
                    cwd=folder,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                for line in proc.stdout:
                    self.log_queue.put(line)
                proc.wait()
                self.log_queue.put(
                    "\n✅ Requirements installed.\n" if proc.returncode == 0 else f"\n❌ Install failed (exit code {proc.returncode}).\n"
                )

                # yt-dlp needs to stay current far more than the other
                # dependencies here — YouTube changes things often enough
                # that "pip install -r requirements.txt" alone can silently
                # leave an old, broken yt-dlp in place (it only installs a
                # version satisfying >=X, not necessarily the newest one).
                # Force it to the latest every time this button is pressed.
                self.log_queue.put("\nUpgrading yt-dlp to the latest version …\n")
                proc2 = subprocess.Popen(
                    [py, "-m", "pip", "install", "--upgrade", "yt-dlp"],
                    cwd=folder,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                for line in proc2.stdout:
                    self.log_queue.put(line)
                proc2.wait()
                self.log_queue.put(
                    "\n✅ Install finished.\n" if proc2.returncode == 0 else f"\n❌ yt-dlp upgrade failed (exit code {proc2.returncode}).\n"
                )
            except Exception as e:
                self.log_queue.put(f"\n❌ Install failed: {e}\n")
            finally:
                self.log_queue.put("__INSTALL_DONE__")

        threading.Thread(target=run_install, daemon=True).start()

    def start_bot(self):
        if self.process is not None:
            return

        info = self._current_bot_info()
        bot_name = self.bot_var.get()
        folder = self.folder_var.get().strip()
        token = self.telegram_var.get().strip()
        gemini_key = self.gemini_var.get().strip()

        if not folder or not os.path.isdir(folder):
            messagebox.showwarning("Missing folder", "Pick the folder that contains this bot's bot.py first.")
            return

        bot_path = os.path.join(folder, "bot.py")
        if not os.path.exists(bot_path):
            messagebox.showerror("bot.py not found", f"No bot.py in:\n{folder}")
            return

        if not token or not gemini_key:
            messagebox.showwarning("Missing info", "Please fill in both the Telegram bot token and the Gemini API key.")
            return

        env_path = os.path.join(folder, ".env")
        env_updates = {info["telegram_env"]: token, info["gemini_env"]: gemini_key}
        if info.get("extra") == "format":
            env_updates["CLIP_FORMAT"] = FORMAT_OPTIONS.get(self.format_var.get(), "tiktok")
            env_updates["BG_STYLE"] = BG_OPTIONS.get(self.bg_var.get(), "blur")
            env_updates["SUBTITLES_ENABLED"] = "true" if self.subtitles_var.get() else "false"
            env_updates["COOKIES_FILE"] = self.cookies_var.get().strip()
            # The launcher's Cookies file picker is now the primary way to
            # set this — clear any stale COOKIES_FROM_BROWSER left over
            # from manual .env editing so it can't silently take priority
            # and shadow the file just picked here.
            env_updates["COOKIES_FROM_BROWSER"] = ""
        elif info.get("extra") == "blur":
            env_updates["BLUR_BACKGROUND"] = "true" if self.blur_var.get() else "false"

        write_env(env_path, env_updates)
        self._append_log(f"Saved keys to {env_path}\n")

        self.config_data.setdefault("folders", {})[bot_name] = folder
        save_launcher_config(self.config_data)
        self.session_cache[bot_name] = self._snapshot_current_fields()

        python_exe = venv_python(folder) if venv_exists(folder) else sys.executable
        if not venv_exists(folder):
            self._append_log(
                "⚠ No isolated environment found for this bot yet — running with the "
                "system Python. Click 📦 Install Requirements first to avoid dependency "
                "conflicts with your other bot.\n"
            )

        try:
            self.process = subprocess.Popen(
                [python_exe, "bot.py"],
                cwd=folder,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except Exception as e:
            messagebox.showerror("Couldn't start bot", str(e))
            return

        self.status_var.set(f"Running: {bot_name}")
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.install_btn.config(state="disabled")
        self.bot_combo.config(state="disabled")
        self._append_log(f"Starting {bot_name} from {folder} …\n")

        threading.Thread(target=self._read_process_output, daemon=True).start()

    def _read_process_output(self):
        if not self.process or not self.process.stdout:
            return
        for line in self.process.stdout:
            self.log_queue.put(line)
        self.log_queue.put("\n[Process ended]\n")
        self.process = None
        self.log_queue.put("__PROCESS_DONE__")

    def _drain_log_queue(self):
        try:
            while True:
                line = self.log_queue.get_nowait()
                if line == "__PROCESS_DONE__":
                    self.status_var.set("Stopped")
                    self.start_btn.config(state="normal")
                    self.stop_btn.config(state="disabled")
                    self.install_btn.config(state="normal")
                    self.bot_combo.config(state="readonly")
                elif line == "__INSTALL_DONE__":
                    self._set_busy(False)
                else:
                    self._append_log(line)
        except queue.Empty:
            pass
        self.root.after(150, self._drain_log_queue)

    def stop_bot(self):
        if self.process is not None:
            self._append_log("Stopping bot…\n")
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
        self.status_var.set("Stopped")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.install_btn.config(state="normal")
        self.bot_combo.config(state="readonly")

    def _on_close(self):
        if self._current_bot_name is not None:
            self.config_data.setdefault("bot_settings", {})[self._current_bot_name] = self._snapshot_current_fields()
            save_launcher_config(self.config_data)
        self.stop_bot()
        self.root.destroy()


def main():
    root = tk.Tk()
    LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
