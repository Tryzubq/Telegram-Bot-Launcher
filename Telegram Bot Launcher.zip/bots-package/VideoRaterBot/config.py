import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot Token
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

# Gemini API Key (for AI-generated titles)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Directories
TEMP_DIR = "temp_videos"
MAX_VIDEO_SIZE_MB = 50
MAX_VIDEO_DURATION_SEC = 60

# Video settings
VIDEO_QUALITY = "best[ext=mp4][height<=1080]"

# Whether square clips get a blurred, zoomed copy of the video as the
# background fill (CapCut-style) instead of a plain black bar. Set via the
# launcher's checkbox, or BLUR_BACKGROUND=false in .env to turn it off.
BLUR_BACKGROUND = os.getenv("BLUR_BACKGROUND", "true").strip().lower() != "false"

# AI settings
USE_GEMINI = True  # Set to False to always use the free fallback titles
