import requests
import logging
import os
import subprocess
import json

logger = logging.getLogger(__name__)


class CobaltDownloader:
    def __init__(self):
        pass
        
    def download_video(self, url: str, output_path: str) -> bool:
        """Download video en valideer"""
        
        # Probeer verschillende methodes voor TikTok
        if 'tiktok.com' in url.lower():
            methods = [
                self._download_tiktok_method1,
                self._download_tiktok_method2,
                self._download_tiktok_method3,
                self._download_tiktok_method4
            ]
        elif 'youtube.com' in url.lower() or 'youtu.be' in url.lower():
            methods = [self._download_youtube]
        else:
            methods = [self._download_generic]
        
        # Probeer elke methode
        for i, method in enumerate(methods, 1):
            try:
                logger.info(f"━━━ Method {i}/{len(methods)}: {method.__name__} ━━━")
                
                if method(url, output_path):
                    if self._validate_video(output_path):
                        logger.info(f"✅ SUCCESS with {method.__name__}!")
                        return True
                    else:
                        logger.warning(f"❌ Validation failed for {method.__name__}")
                        if os.path.exists(output_path):
                            os.remove(output_path)
                else:
                    logger.warning(f"❌ {method.__name__} returned False")
                        
            except Exception as e:
                logger.error(f"❌ {method.__name__} exception: {e}", exc_info=True)
                continue
        
        logger.error("❌ All download methods failed")
        return False
    
    def _download_tiktok_method1(self, url: str, output_path: str) -> bool:
        """TikTok via TikWM API"""
        try:
            logger.info("Trying TikWM API...")
            api_url = "https://www.tikwm.com/api/"
            
            response = requests.post(
                api_url,
                data={'url': url},
                headers={'User-Agent': 'Mozilla/5.0'},
                timeout=30
            )
            
            logger.info(f"TikWM Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"TikWM Response: {json.dumps(data, indent=2)[:500]}")
                
                if data.get('code') == 0:
                    video_data = data.get('data', {})
                    download_url = video_data.get('hdplay') or video_data.get('play')
                    
                    if download_url:
                        logger.info(f"Found video URL: {download_url[:100]}...")
                        return self._download_file(download_url, output_path)
                    else:
                        logger.error("No video URL in response")
                else:
                    logger.error(f"TikWM error code: {data.get('code')}, msg: {data.get('msg')}")
            
            return False
            
        except Exception as e:
            logger.error(f"TikWM exception: {e}")
            return False
    
    def _download_tiktok_method2(self, url: str, output_path: str) -> bool:
        """TikTok via Snaptik"""
        try:
            logger.info("Trying Snaptik...")
            
            # Stap 1: GET request naar snaptik
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            
            # Haal de pagina op
            response = session.get('https://snaptik.app/', timeout=15)
            logger.info(f"Snaptik homepage: {response.status_code}")
            
            # POST naar API
            api_response = session.post(
                'https://snaptik.app/abc2.php',
                data={'url': url, 'lang': 'en'},
                headers={
                    'Accept': '*/*',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Origin': 'https://snaptik.app',
                    'Referer': 'https://snaptik.app/'
                },
                timeout=30
            )
            
            logger.info(f"Snaptik API Status: {api_response.status_code}")
            logger.info(f"Snaptik Response preview: {api_response.text[:300]}")
            
            if api_response.status_code == 200:
                import re
                # Zoek download link
                matches = re.findall(r'href="([^"]+)"', api_response.text)
                
                for match in matches:
                    if 'tikcdn.io' in match or 'snaptik' in match:
                        logger.info(f"Found Snaptik URL: {match[:100]}")
                        if self._download_file(match, output_path):
                            return True
            
            return False
            
        except Exception as e:
            logger.error(f"Snaptik exception: {e}")
            return False
    
    def _download_tiktok_method3(self, url: str, output_path: str) -> bool:
        """TikTok via TikTokAPI (unofficial)"""
        try:
            logger.info("Trying TikTokAPI...")
            
            api_url = "https://api.tiklydown.eu.org/api/download"
            
            response = requests.post(
                api_url,
                json={'url': url},
                headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Content-Type': 'application/json'
                },
                timeout=30
            )
            
            logger.info(f"TikTokAPI Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"TikTokAPI Response: {json.dumps(data, indent=2)[:500]}")
                
                video_url = data.get('video', {}).get('noWatermark')
                
                if video_url:
                    logger.info(f"Found no-watermark URL")
                    return self._download_file(video_url, output_path)
                else:
                    logger.error("No video URL in TikTokAPI response")
            
            return False
            
        except Exception as e:
            logger.error(f"TikTokAPI exception: {e}")
            return False
    
    def _download_tiktok_method4(self, url: str, output_path: str) -> bool:
        """TikTok via yt-dlp (laatste redmiddel)"""
        try:
            logger.info("Trying yt-dlp as fallback...")
            import yt_dlp
            
            ydl_opts = {
                'format': 'best',
                'outtmpl': output_path,
                'quiet': False,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
            
            if os.path.exists(output_path):
                logger.info(f"yt-dlp downloaded: {os.path.getsize(output_path)} bytes")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"yt-dlp exception: {e}")
            return False
    
    def _download_youtube(self, url: str, output_path: str) -> bool:
        """YouTube via yt-dlp"""
        return self._download_tiktok_method4(url, output_path)
    
    def _download_generic(self, url: str, output_path: str) -> bool:
        """Generieke download"""
        return self._download_file(url, output_path)
    
    def _download_file(self, url: str, output_path: str) -> bool:
        """Download bestand van URL"""
        try:
            logger.info(f"Downloading file from: {url[:150]}...")
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/',
                'Accept': '*/*',
                'Accept-Encoding': 'identity'
            }
            
            response = requests.get(
                url, 
                stream=True, 
                timeout=120, 
                headers=headers, 
                allow_redirects=True
            )
            
            logger.info(f"Download response: {response.status_code}")
            logger.info(f"Content-Type: {response.headers.get('content-type')}")
            logger.info(f"Content-Length: {response.headers.get('content-length')}")
            
            if response.status_code != 200:
                return False
            
            # Download met progress
            total_size = 0
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        total_size += len(chunk)
            
            logger.info(f"✅ Downloaded {total_size} bytes to {output_path}")
            
            if total_size < 50000:
                logger.error("File too small!")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Download file exception: {e}")
            return False
    
    def _validate_video(self, video_path: str) -> bool:
        """Valideer video"""
        try:
            if not os.path.exists(video_path):
                logger.error("Video file doesn't exist")
                return False
            
            file_size = os.path.getsize(video_path)
            logger.info(f"Validating: {file_size} bytes")
            
            if file_size < 50000:
                logger.error("File too small")
                return False
            
            # FFprobe check
            try:
                result = subprocess.run(
                    ['ffprobe', '-v', 'error', '-show_entries', 
                     'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 
                     video_path],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if result.returncode == 0:
                    duration = result.stdout.strip()
                    duration_float = float(duration)
                    
                    if duration_float > 0:
                        logger.info(f"✅ Valid video: {duration_float}s")
                        return True
                    else:
                        logger.error("Video duration is 0")
                        return False
                else:
                    logger.error(f"FFprobe error: {result.stderr}")
                    return False
                    
            except FileNotFoundError:
                logger.warning("FFprobe not available, accepting based on size")
                return file_size > 100000
            
        except Exception as e:
            logger.error(f"Validation exception: {e}")
            return False
    
    def is_supported(self, url: str) -> bool:
        """Check support"""
        supported = ['tiktok.com', 'youtube.com', 'youtu.be', 'instagram.com']
        return any(domain in url.lower() for domain in supported)
