import logging
import random
from io import BytesIO
from PIL import Image
import os

logger = logging.getLogger(__name__)


class AIService:
    def __init__(self):
        self.fallback_titles = [
            "Must See",
            "Epic Moment",
            "Perfect Shot",
            "Going Viral",
            "Insane Skills",
            "Too Funny",
            "Mind Blowing",
            "Amazing",
            "Top Tier",
            "Pure Gold",
            "Legendary",
            "Wild Move",
            "Stunning",
            "Crazy Skills",
            "Next Level"
        ]

    async def generate_title(self, video_path: str) -> tuple:
        """Generate a title via AI, or fall back to a random one.
        Returns (title, tokens_used)."""
        try:
            gemini_key = os.getenv('GEMINI_API_KEY')

            if gemini_key and gemini_key.startswith('AQ.'):
                return await self._generate_with_gemini(video_path)
            else:
                title = random.choice(self.fallback_titles)
                logger.info(f"Using fallback title: {title}")
                return title, 0

        except Exception as e:
            logger.error(f"AI error: {e}")
            return random.choice(self.fallback_titles), 0

    async def _generate_with_gemini(self, video_path: str) -> tuple:
        """Use the Gemini Vision API. Returns (title, tokens_used)."""
        try:
            import google.generativeai as genai
            from moviepy.editor import VideoFileClip

            genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
            model = genai.GenerativeModel("gemini-1.5-flash")

            # Extract a frame
            video = VideoFileClip(video_path)
            frame_time = min(video.duration / 2, 3)
            frame = video.get_frame(frame_time)
            video.close()

            img = Image.fromarray(frame)
            img.thumbnail((800, 800), Image.LANCZOS)

            buffered = BytesIO()
            img.save(buffered, format="JPEG", quality=85)
            buffered.seek(0)
            img_for_gemini = Image.open(buffered)

            logger.info("Calling Gemini Vision API...")

            prompt = (
                "Analyze this video frame. Create a SHORT 2-3 word description. "
                "NO emojis. Examples: 'Epic Fail', 'Perfect Shot', 'Insane Move'. "
                "Only the description:"
            )

            response = model.generate_content(
                [prompt, img_for_gemini],
                generation_config=genai.types.GenerationConfig(
                    max_output_tokens=15,
                    temperature=0.9
                )
            )

            title = response.text.strip()
            title = title.replace('"', '').replace("'", '').strip()

            if title.endswith('.') or title.endswith('!') or title.endswith('?'):
                title = title[:-1]

            title = title[:30]

            tokens_used = 0
            try:
                tokens_used = response.usage_metadata.total_token_count
            except Exception:
                pass

            logger.info(f"Gemini generated: {title} ({tokens_used} tokens)")
            return title, tokens_used

        except Exception as e:
            logger.error(f"Gemini Vision error: {e}")
            return random.choice(self.fallback_titles), 0
