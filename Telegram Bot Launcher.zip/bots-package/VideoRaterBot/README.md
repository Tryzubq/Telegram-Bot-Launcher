# Video Rater Bot

Send TikTok/YouTube Shorts/Instagram Reels links; each one gets trimmed,
optionally titled (AI or your own text), and merged into a single growing
"countdown" video with rankings that appear progressively as each clip starts.

## This is a separate project from "Clip & Caption Bot"

If you also have the other Telegram bot (the auto/manual YouTube clipper),
keep this in its **own folder**, completely separate from that one. They
are two different bots with two different `bot.py` files, two different
`requirements.txt` files, and two different environment variable names for
the Telegram token (this one uses `TELEGRAM_TOKEN`, the other uses
`TELEGRAM_BOT_TOKEN`). Pointing both at the same folder will overwrite one
bot's files with the other's and cause import errors.

## Setup

1. **Install requirements** — easiest way is via the shared Bot Launcher
   that comes with the Clip & Caption Bot project: open it, switch the
   dropdown to "Video Rater Bot," click Browse and select *this* folder,
   then click **📦 Install Requirements**. This creates an isolated `.venv`
   inside this folder so its dependencies never conflict with the other
   bot's.

   Or manually, from inside this folder:
   ```
   py -m venv .venv
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

2. **Patch moviepy for Pillow 10+** — moviepy 1.0.3 references
   `Image.ANTIALIAS`, which modern Pillow removed. Run this once, with the
   same Python/venv you just installed into:
   ```
   .venv\Scripts\python.exe fix_moviepy.py
   ```

3. **Set your keys** — either via the shared launcher (paste in Telegram
   token + Gemini key, press Start — a "Blur background behind square
   clips" checkbox also appears there), or manually copy `.env.example` to
   `.env` and fill it in:
   ```
   TELEGRAM_TOKEN=your_bot_father_token
   GEMINI_API_KEY=your_gemini_key
   BLUR_BACKGROUND=true
   ```

4. **Run it** — via the launcher's ▶ Start Bot, or manually:
   ```
   .venv\Scripts\python.exe bot.py
   ```
   (or just double-click `start.bat`)

## Notes

- The top title banner is now horizontally centered (each wrapped line
  individually), rather than left-aligned from the margin like the
  original code did.
- `BLUR_BACKGROUND` (default `true`) controls whether square clips get a
  blurred, zoomed copy of the video as the fill behind them (CapCut-style)
  or a plain black bar — set it via the launcher's checkbox or in `.env`.
- `ai_service.py` only calls Gemini Vision for titles if your key starts
  with `AQ.` — otherwise it uses a random fallback title. This was a
  deliberate check in the original code; remove it in `ai_service.py` if
  your key doesn't start with `AQ.` and you still want AI titles.
- `cobalt_downloader.py` tries several third-party TikTok download APIs
  before falling back to `yt-dlp`. Those third-party services
  (TikWM, Snaptik, tiklydown) can go down or change independently of
  anything in this codebase — if TikTok downloads fail, yt-dlp (method 4)
  is the most reliable fallback, so keeping it updated (`pip install -U
  yt-dlp` inside this project's `.venv`) helps most.
- `requirements.txt` here has two changes from the original: `yt-dlp` is
  unpinned (was pinned to a 2023 version that no longer works reliably
  against TikTok/YouTube's current sites) and `Pillow` requires `>=10.4.0`
  (the previously pinned 10.1.0 has no Python 3.13 wheel and fails to
  build from source).
