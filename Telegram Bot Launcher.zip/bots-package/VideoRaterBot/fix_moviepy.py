"""
Run this once after installing requirements — moviepy 1.0.3 references
Image.ANTIALIAS, which was removed in Pillow 10+. This patches moviepy's
resize.py in place to use Image.LANCZOS instead (the modern equivalent).

Run it with whatever Python/venv you installed requirements.txt into, e.g.:
    .venv\\Scripts\\python.exe fix_moviepy.py     (Windows)
    .venv/bin/python fix_moviepy.py               (Mac/Linux)
"""

import os
import sys
import sysconfig


def find_moviepy_resize() -> str | None:
    # Look in the current interpreter's own site-packages first (this
    # matters once you're running inside a per-bot virtual environment).
    candidates = [os.path.join(sysconfig.get_paths()["purelib"], "moviepy", "video", "fx", "resize.py")]
    for path in sys.path:
        candidates.append(os.path.join(path, "moviepy", "video", "fx", "resize.py"))
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return None


def main():
    resize_path = find_moviepy_resize()

    if not resize_path:
        print("❌ Could not find moviepy's resize.py in this Python environment.")
        print("   Make sure you're running this with the same Python (or venv) you installed requirements.txt into.")
        return

    print(f"✅ Found: {resize_path}")

    with open(resize_path, "r", encoding="utf-8") as f:
        content = f.read()

    backup_path = resize_path + ".backup"
    if not os.path.exists(backup_path):
        with open(backup_path, "w", encoding="utf-8") as f:
            f.write(content)
        print("✅ Backup created")
    else:
        print("ℹ️  Backup already exists, skipping")

    original_count = content.count("Image.ANTIALIAS")
    if original_count == 0:
        print("ℹ️  No Image.ANTIALIAS references found — already patched or not needed.")
        return

    content = content.replace("Image.ANTIALIAS", "Image.LANCZOS")

    with open(resize_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✅ Fixed! Replaced {original_count} occurrence(s) of Image.ANTIALIAS with Image.LANCZOS")
    print("🎉 moviepy is now compatible with Pillow 10+")


if __name__ == "__main__":
    main()
