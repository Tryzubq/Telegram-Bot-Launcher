import os
import re
import logging
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)
from video_processor import VideoProcessor
from ai_service import AIService
from config import TELEGRAM_TOKEN, TEMP_DIR, MAX_VIDEO_DURATION_SEC, BLUR_BACKGROUND

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

WAITING_FOR_LINK, WAITING_FOR_TIMESTAMPS, WAITING_FOR_CUSTOM_TEXT, WAITING_FOR_TOP_TEXT = range(4)

os.makedirs(TEMP_DIR, exist_ok=True)


class VideoBot:
    def __init__(self):
        self.video_processor = VideoProcessor(TEMP_DIR)
        self.ai_service = AIService()
        self.user_videos = {}
        self.user_top_title = {}
        self.user_tokens = {}     # {user_id: total gemini tokens used this session}

    # ------------------------------------------------------------------
    # Core conversation flow
    # ------------------------------------------------------------------

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        self.user_videos[user_id] = []
        self.user_top_title[user_id] = ""
        self.user_tokens[user_id] = 0

        await update.message.reply_text(
            "🎥 *Video Rater Bot*\n\n"
            "Send TikTok/YouTube links!\n\n"
            "📊 Rankings appear as each clip starts\n"
            "📝 New video goes BEFORE the old one\n\n"
            "*Commands:*\n"
            "/reset - Start over\n"
            "/cancel - Cancel current action",
            parse_mode='Markdown'
        )
        return WAITING_FOR_LINK

    async def reset(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id

        if user_id in self.user_videos:
            for video_data in self.user_videos[user_id]:
                if os.path.exists(video_data['path']):
                    try:
                        os.remove(video_data['path'])
                    except:
                        pass

        self.user_videos[user_id] = []
        self.user_top_title[user_id] = ""
        self.user_tokens[user_id] = 0
        self.video_processor.cleanup_user_files(user_id)

        await update.message.reply_text("🔄 Reset! Send a link for #1.")
        return WAITING_FOR_LINK

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text.strip()
        current_state = context.user_data.get('state', 'link')

        if current_state == 'custom_text':
            return await self.handle_custom_text(update, context)
        elif current_state == 'top_text':
            return await self.handle_top_text(update, context)

        if self._is_valid_url(text):
            return await self.handle_link(update, context)

        start_time, end_time = self._parse_timestamps(text)
        if start_time is not None and end_time is not None:
            return await self.handle_timestamps(update, context)

        await update.message.reply_text("❌ Send:\n• A link, OR\n• Timestamps: `5 - 15`", parse_mode='Markdown')
        return WAITING_FOR_LINK

    async def handle_link(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        url = update.message.text.strip()
        user_id = update.effective_user.id

        if not self._is_valid_url(url):
            await update.message.reply_text("❌ Invalid link.")
            return WAITING_FOR_LINK

        status_msg = await update.message.reply_text("⏳ Downloading...")

        try:
            video_path = await self.video_processor.download_video(url, user_id)

            if not video_path:
                await status_msg.edit_text("❌ Download failed.")
                return WAITING_FOR_LINK

            context.user_data['original_video'] = video_path
            duration = self.video_processor.get_duration(video_path)
            context.user_data['video_duration'] = duration

            context.user_data['state'] = 'timestamps'

            file_size_mb = os.path.getsize(video_path) / (1024 * 1024)
            example_end = int(min(duration, MAX_VIDEO_DURATION_SEC)) or 1

            caption = (
                f"✅ Downloaded ({file_size_mb:.1f}MB, {duration:.0f}s)\n\n"
                f"Send timestamps, e.g. `1 - {example_end}`"
            )

            await status_msg.edit_text("📤 Preview...")

            try:
                with open(video_path, 'rb') as video_file:
                    await update.message.reply_video(
                        video=video_file,
                        caption=caption,
                        parse_mode='Markdown',
                        read_timeout=90,
                        write_timeout=90
                    )
                await status_msg.delete()
            except:
                await status_msg.edit_text(caption, parse_mode='Markdown')

            return WAITING_FOR_TIMESTAMPS

        except Exception as e:
            logger.error(f"Link error: {e}")
            await status_msg.edit_text(f"❌ Error: {str(e)}")
            return WAITING_FOR_LINK

    async def handle_timestamps(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text.strip()
        user_id = update.effective_user.id
        start_time, end_time = self._parse_timestamps(text)

        if start_time is None or end_time is None:
            await update.message.reply_text("❌ Invalid. Use: `5 - 15`", parse_mode='Markdown')
            return WAITING_FOR_TIMESTAMPS

        if start_time >= end_time:
            await update.message.reply_text("❌ Start must be before end!")
            return WAITING_FOR_TIMESTAMPS

        context.user_data['start_time'] = start_time
        context.user_data['end_time'] = end_time

        is_first = (user_id not in self.user_videos or len(self.user_videos[user_id]) == 0)

        if is_first:
            context.user_data['state'] = 'top_text'
            await update.message.reply_text(
                "✅ Timestamps saved!\n\n"
                "📝 *Title at the top:*\n• Type a title\n• OR `skip`",
                parse_mode='Markdown'
            )
            return WAITING_FOR_TOP_TEXT
        else:
            context.user_data['state'] = 'custom_text'
            await update.message.reply_text(
                "✅ Timestamps saved!\n\n"
                "📝 *Ranking text:*\n• `auto` - AI\n• `skip`\n• Or type your own text",
                parse_mode='Markdown'
            )
            return WAITING_FOR_CUSTOM_TEXT

    async def handle_top_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_input = update.message.text.strip()
        user_id = update.effective_user.id

        if user_input.lower() == 'skip':
            self.user_top_title[user_id] = ""
        else:
            self.user_top_title[user_id] = user_input[:40]

        context.user_data['state'] = 'custom_text'

        await update.message.reply_text(
            "✅ Title saved!\n\n"
            "📝 *Ranking:*\n• `auto`\n• `skip`\n• Or type your own text",
            parse_mode='Markdown'
        )

        return WAITING_FOR_CUSTOM_TEXT

    async def handle_custom_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_input = update.message.text.strip()
        user_id = update.effective_user.id
        start_time = context.user_data.get('start_time')
        end_time = context.user_data.get('end_time')
        return await self._generate_and_merge(update, context, user_id, start_time, end_time, user_input)

    async def _generate_and_merge(self, update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   user_id: int, start_time, end_time, ranking_input: str):
        """Shared pipeline: trim -> (AI) title -> merge -> send.
        Used by both the manual flow and the auto-all flow."""

        if user_id not in self.user_videos:
            self.user_videos[user_id] = []

        current_ranking = len(self.user_videos[user_id]) + 1
        status_msg = await update.message.reply_text(f"⚙️ Processing video #{current_ranking}...")

        try:
            original_video = context.user_data.get('original_video')

            if not original_video or start_time is None or end_time is None:
                raise Exception("Missing data")

            top_title = self.user_top_title.get(user_id, "")

            await status_msg.edit_text(f"✂️ Trimming... (#{current_ranking})")
            clipped_path = await self.video_processor.trim_video(
                original_video, start_time, end_time, user_id, no_blur=not BLUR_BACKGROUND
            )

            tokens_used = 0
            if ranking_input.lower() == 'skip':
                ranking_text = ""
            elif ranking_input.lower() == 'auto':
                await status_msg.edit_text(f"🤖 AI thinking... (#{current_ranking})")
                ranking_text, tokens_used = await self.ai_service.generate_title(clipped_path)
            else:
                ranking_text = ranking_input[:30]

            if tokens_used:
                self.user_tokens[user_id] = self.user_tokens.get(user_id, 0) + tokens_used

            from moviepy.editor import VideoFileClip
            current_clip = VideoFileClip(clipped_path)
            clip_duration = current_clip.duration
            current_clip.close()

            # Unique filename for this clip
            unique_clip_path = os.path.join(self.video_processor.temp_dir, f"{user_id}_clip_{current_ranking}.mp4")

            import shutil
            shutil.copy(clipped_path, unique_clip_path)

            new_entry = {
                'path': unique_clip_path,
                'ranking': current_ranking,
                'title': ranking_text,
                'duration': clip_duration,
                'start_time_in_merge': 0
            }

            self.user_videos[user_id].insert(0, new_entry)

            cumulative = 0
            for video_data in self.user_videos[user_id]:
                video_data['start_time_in_merge'] = cumulative
                cumulative += video_data['duration']

            await status_msg.edit_text("🎨 Adding overlay...")

            all_rankings = []
            for video_data in self.user_videos[user_id]:
                all_rankings.append({
                    'ranking': video_data['ranking'],
                    'text': video_data['title'],
                    'start_time': video_data['start_time_in_merge'],
                    'duration': video_data['duration']
                })

            merged_path = await self.video_processor.merge_videos_with_progressive_overlay(
                self.user_videos[user_id], user_id, top_title, all_rankings
            )

            merged_size_mb = os.path.getsize(merged_path) / (1024 * 1024)

            await status_msg.edit_text(f"📤 Uploading... ({merged_size_mb:.1f}MB)")

            caption = f"✨ *Update!*\n\n📊 {current_ranking} clips\n🆕 #{current_ranking}. {ranking_text}\n"
            if top_title:
                caption += f"📌 {top_title}\n"
            session_tokens = self.user_tokens.get(user_id, 0)
            if session_tokens:
                caption += f"🔢 Gemini tokens used this session: {session_tokens}\n"
            caption += f"\n💡 Send a link for #{current_ranking + 1}!"

            try:
                with open(merged_path, 'rb') as video_file:
                    await update.message.reply_video(
                        video=video_file,
                        caption=caption,
                        parse_mode='Markdown',
                        supports_streaming=True,
                        read_timeout=300,
                        write_timeout=300
                    )
                await status_msg.delete()
            except:
                with open(merged_path, 'rb') as video_file:
                    await update.message.reply_document(
                        document=video_file,
                        caption=f"✨ {current_ranking} clips",
                        read_timeout=300,
                        write_timeout=300
                    )
                await status_msg.delete()

            context.user_data.clear()
            context.user_data['state'] = 'link'

            return WAITING_FOR_LINK

        except Exception as e:
            logger.error(f"Error: {e}", exc_info=True)
            await status_msg.edit_text(f"❌ Error:\n{str(e)[:200]}\n\nSend a link!")
            context.user_data.clear()
            return WAITING_FOR_LINK

    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        self.video_processor.cleanup_user_files(update.effective_user.id)
        context.user_data.clear()
        await update.message.reply_text("❌ Cancelled!")
        return WAITING_FOR_LINK

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_valid_url(self, url: str) -> bool:
        patterns = [r'tiktok\.com', r'youtube\.com/shorts', r'youtu\.be', r'instagram\.com/reel']
        return any(re.search(p, url, re.I) for p in patterns)

    def _parse_timestamps(self, text: str):
        patterns = [
            r'(\d+):(\d+)\s*-\s*(\d+):(\d+)',
            r'(\d+)\s*-\s*(\d+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                groups = match.groups()
                if len(groups) == 4:
                    return int(groups[0]) * 60 + int(groups[1]), int(groups[2]) * 60 + int(groups[3])
                elif len(groups) == 2:
                    return int(groups[0]), int(groups[1])
        return None, None


def main():
    bot = VideoBot()
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', bot.start),
            MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_message)
        ],
        states={
            WAITING_FOR_LINK: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_message)],
            WAITING_FOR_TIMESTAMPS: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_message)],
            WAITING_FOR_TOP_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_message)],
            WAITING_FOR_CUSTOM_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_message)],
        },
        fallbacks=[
            CommandHandler('cancel', bot.cancel),
            CommandHandler('reset', bot.reset)
        ],
    )

    application.add_handler(conv_handler)

    logger.info("🤖 Bot started!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
