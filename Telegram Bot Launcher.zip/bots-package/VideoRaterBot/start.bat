@echo off
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" bot.py
) else (
    where py >nul 2>nul
    if %errorlevel%==0 (
        py bot.py
    ) else (
        python bot.py
    )
)

if errorlevel 1 (
    echo.
    echo Something went wrong. Make sure you've installed requirements.txt
    echo (either via the shared Bot Launcher's Install Requirements button,
    echo or manually with: py -m pip install -r requirements.txt)
    pause
)
