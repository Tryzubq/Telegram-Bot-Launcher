import os
import logging
from moviepy.editor import VideoFileClip, concatenate_videoclips, ColorClip
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
from cobalt_downloader import CobaltDownloader

logger = logging.getLogger(__name__)


class VideoProcessor:
    def __init__(self, temp_dir: str):
        self.temp_dir = temp_dir
        os.makedirs(temp_dir, exist_ok=True)
        self.cobalt = CobaltDownloader()

        # Hype keywords with colors (RGB) - used for the top title
        self.keyword_colors = {
            'epic': (255, 0, 0), 'insane': (255, 69, 0), 'crazy': (255, 140, 0),
            'perfect': (0, 255, 0), 'amazing': (0, 191, 255), 'legendary': (255, 215, 0),
            'viral': (255, 20, 147), 'fire': (255, 69, 0), 'wild': (138, 43, 226),
            'top': (0, 255, 127), 'best': (255, 215, 0), 'goal': (0, 255, 0),
            'skill': (0, 191, 255), 'fail': (255, 0, 0), 'win': (0, 255, 0),
            'must-see': (255, 20, 147), 'unreal': (255, 69, 0), 'clutch': (0, 255, 127),
        }

    async def download_video(self, url: str, user_id: int) -> str:
        output_path = os.path.join(self.temp_dir, f"{user_id}_original.mp4")

        if os.path.exists(output_path):
            try:
                os.remove(output_path)
            except:
                pass

        try:
            if not self.cobalt.is_supported(url):
                return None

            success = self.cobalt.download_video(url, output_path)
            return output_path if (success and os.path.exists(output_path)) else None

        except Exception as e:
            logger.error(f"Download error: {e}")
            return None

    def get_duration(self, video_path: str) -> float:
        """Return the duration (seconds) of a video file."""
        clip = VideoFileClip(video_path)
        duration = clip.duration
        clip.close()
        return duration

    async def trim_video(self, video_path: str, start: int, end: int, user_id: int, no_blur: bool = False) -> str:
        output_path = os.path.join(self.temp_dir, f"{user_id}_clipped.mp4")

        try:
            video = VideoFileClip(video_path)

            if end > video.duration:
                end = video.duration
            if start >= end:
                raise ValueError("Invalid timestamps")

            clipped = video.subclip(start, end)
            square_in_vertical = self._make_square_in_vertical_canvas(clipped, no_blur=no_blur)

            square_in_vertical.write_videofile(
                output_path, codec='libx264', audio_codec='aac',
                logger=None, preset='ultrafast', threads=4, bitrate='3000k'
            )

            video.close()
            clipped.close()
            square_in_vertical.close()

            return output_path

        except Exception as e:
            logger.error(f"Trim error: {e}")
            raise

    def _make_square_in_vertical_canvas(self, video_clip, no_blur: bool = False):
        width, height = video_clip.size
        canvas_width, canvas_height, square_size = 1080, 1920, 1080

        if no_blur:
            # Plain black background instead of a blurred video (faster + cleaner look)
            background = ColorClip(size=(canvas_width, canvas_height), color=(0, 0, 0), duration=video_clip.duration)
            background = background.set_fps(video_clip.fps)
        else:
            def make_blur_background(t):
                frame = video_clip.get_frame(t)
                img = Image.fromarray(frame)
                blurred = img.resize((canvas_width, canvas_height), Image.LANCZOS)
                return np.array(blurred.filter(ImageFilter.GaussianBlur(radius=18)))

            from moviepy.video.VideoClip import VideoClip
            background = VideoClip(make_frame=make_blur_background, duration=video_clip.duration)
            background = background.set_fps(video_clip.fps)

        original_aspect = width / height

        if original_aspect > 1:
            square_video = video_clip.crop(x1=(width - height) // 2, y1=0, width=height, height=height)
        elif original_aspect < 1:
            square_video = video_clip.crop(x1=0, y1=(height - width) // 2, width=width, height=width)
        else:
            square_video = video_clip

        def resize_frame(get_frame, t):
            return np.array(Image.fromarray(get_frame(t)).resize((square_size, square_size), Image.LANCZOS))

        square_video = square_video.fl(resize_frame, apply_to=['mask'])
        square_video.size = (square_size, square_size)
        square_video = square_video.set_position((0, (canvas_height - square_size) // 2))

        from moviepy.editor import CompositeVideoClip
        return CompositeVideoClip([background, square_video], size=(canvas_width, canvas_height))

    async def merge_videos_with_progressive_overlay(self, video_list: list, user_id: int, top_title: str, all_rankings: list) -> str:
        """
        Merge videos with progressive text overlay.
        Video order: newest first (video_list[0] = newest)
        """
        output_path = os.path.join(self.temp_dir, f"{user_id}_merged.mp4")

        try:
            logger.info(f"=== MERGING {len(video_list)} VIDEOS ===")

            for r in all_rankings:
                logger.info(f"  #{r['ranking']}: '{r['text']}' @ {r['start_time']}s (duration: {r['duration']}s)")

            clips = []
            for idx, video_data in enumerate(video_list):
                if os.path.exists(video_data['path']):
                    clip = VideoFileClip(video_data['path'])
                    clips.append(clip)
                    logger.info(f"Position {idx}: Clip #{video_data['ranking']} '{video_data['title']}' ({video_data['duration']:.2f}s) @ {video_data['start_time_in_merge']}s")

            if not clips:
                raise Exception("No videos")

            base_video = concatenate_videoclips(clips, method="compose")
            width, height = base_video.size
            duration = base_video.duration
            fps = base_video.fps

            logger.info(f"Merged base video: {width}x{height}, {duration:.2f}s, {fps} fps")

            # Fonts - bold condensed style closer to the reference image
            font_size_title = max(70, int(height * 0.055))
            font_size_ranking = max(50, int(height * 0.032))

            font_title = None
            font_ranking = None
            for font_name in ("impact.ttf", "Impact.ttf", "arialbd.ttf", "arial.ttf"):
                try:
                    font_title = ImageFont.truetype(font_name, font_size_title)
                    font_ranking = ImageFont.truetype(font_name, font_size_ranking)
                    break
                except Exception:
                    continue
            if font_title is None:
                font_title = ImageFont.load_default()
                font_ranking = ImageFont.load_default()

            x_margin = int(width * 0.08)
            x_margin_ranking = int(width * 0.04)
            y_title = int(height * 0.06)
            y_start = int(height * 0.27)
            y_spacing = int(height * 0.11)
            line_height_title = int(font_size_title * 1.15)

            frame_count = [0]

            def add_text_to_frame(get_frame, t):
                """Draw text on top of a frame"""
                frame = get_frame(t)
                img = Image.fromarray(frame)
                draw = ImageDraw.Draw(img)

                if frame_count[0] < 5:
                    logger.info(f"FRAME {frame_count[0]} @ t={t:.2f}s")
                    frame_count[0] += 1

                # TITLE (always visible, plain white, bigger font, wraps if too long, centered)
                if top_title:
                    max_title_width = width - (2 * x_margin)

                    # Wrap into lines that fit the available width first, so
                    # each finished line's width is known before drawing —
                    # needed to center it, rather than drawing greedily
                    # word-by-word from the left margin.
                    title_lines, current_line = [], ""
                    for word in top_title.split():
                        trial = f"{current_line} {word}".strip()
                        bbox = draw.textbbox((0, 0), trial, font=font_title)
                        if bbox[2] - bbox[0] <= max_title_width or not current_line:
                            current_line = trial
                        else:
                            title_lines.append(current_line)
                            current_line = word
                    if current_line:
                        title_lines.append(current_line)

                    y_current = y_title
                    for line in title_lines:
                        bbox = draw.textbbox((0, 0), line, font=font_title)
                        line_width = bbox[2] - bbox[0]
                        x_current = (width - line_width) // 2

                        for dx in range(-3, 4):
                            for dy in range(-3, 4):
                                if dx != 0 or dy != 0:
                                    draw.text((x_current + dx, y_current + dy), line, font=font_title, fill=(0, 0, 0))
                        draw.text((x_current, y_current), line, font=font_title, fill=(255, 255, 255))

                        y_current += line_height_title

                # RANKINGS (appear once their clip starts, then stay visible for the rest of the video)
                visible_rankings = [r for r in all_rankings if r['start_time'] <= t]

                if frame_count[0] <= 5:
                    logger.info(f"  Visible: {[(r['ranking'], r['text']) for r in visible_rankings]}")

                for idx, rank in enumerate(visible_rankings):
                    y_pos = y_start + (idx * y_spacing)
                    full_text = f"#{rank['ranking']}. {rank['text']}" if rank['text'] else f"#{rank['ranking']}"

                    for dx in range(-2, 3):
                        for dy in range(-2, 3):
                            if dx != 0 or dy != 0:
                                draw.text((x_margin_ranking + dx, y_pos + dy), full_text, font=font_ranking, fill=(0, 0, 0))
                    draw.text((x_margin_ranking, y_pos), full_text, font=font_ranking, fill=(255, 255, 255))

                return np.array(img)

            final_video = base_video.fl(add_text_to_frame, apply_to=[])

            final_video.write_videofile(
                output_path, codec='libx264', audio_codec='aac',
                logger=None, preset='medium', threads=4, bitrate='2500k',
                fps=fps
            )

            for clip in clips:
                clip.close()
            base_video.close()
            final_video.close()

            logger.info("=== MERGE COMPLETE ===")
            return output_path

        except Exception as e:
            logger.error(f"Merge error: {e}", exc_info=True)
            raise

    def cleanup_user_files(self, user_id: int):
        import time
        import glob

        patterns = [f"{user_id}_original.mp4", f"{user_id}_clipped.mp4", f"{user_id}_ranked_*.mp4",
                    f"{user_id}_clip_*.mp4", f"{user_id}_merged.mp4"]

        for pattern in patterns:
            for file_path in glob.glob(os.path.join(self.temp_dir, pattern)):
                if os.path.exists(file_path):
                    for attempt in range(3):
                        try:
                            os.remove(file_path)
                            break
                        except:
                            if attempt < 2:
                                time.sleep(0.5)
